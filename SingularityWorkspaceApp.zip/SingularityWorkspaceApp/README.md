# Singularity Workspace Android App

A native Android APK that provides an AI-powered development environment, terminal, file manager, and remote workspace controller.

## Features

- **AI Chat**: OpenAI-compatible API integration with streaming support
- **Terminal**: Full shell execution with local `/system/bin/sh` access
- **File Manager**: Browse, open, share, rename, delete files
- **Remote Workspace**: SSH tunnel to code-server and AI gateway
- **Settings**: Quick presets for OpenAI, Mistral, DeepSeek, OpenRouter
- **Native Android**: Built with Java, no WebView dependency for core features

## Architecture

```
SingularityWorkspace.apk
├── MainActivity (Dashboard)
│   ├── AI Chat panel
│   ├── Status indicators
│   └── Quick action buttons
├── TerminalActivity
│   ├── Interactive shell (/system/bin/sh)
│   ├── AI query mode
│   └── Quick command buttons
├── SettingsActivity
│   ├── AI provider config
│   ├── Remote workspace config
│   └── Provider presets
├── FileManagerActivity
│   ├── File browser
│   ├── File operations
│   └── MIME type handling
├── SSHService (background)
│   └── SSH tunnel to remote VM
└── LocalServerService (optional)
    └── Local HTTP server
```

## Build Requirements

- Android SDK (API 35)
- Build Tools 35.0.0
- OpenJDK 17
- Platform: `android-35`

### Install Android SDK

```bash
# If you don't have Android SDK installed:
export ANDROID_HOME=$HOME/android-sdk
mkdir -p $ANDROID_HOME/cmdline-tools
cd /tmp
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-11076708_latest.zip
mv cmdline-tools $ANDROID_HOME/cmdline-tools/latest
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$PATH"

# Install required packages
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0"
```

## Build

```bash
cd SingularityWorkspaceApp
export ANDROID_HOME=$HOME/android-sdk
./build-apk.sh
```

Output: `build/SingularityWorkspace-debug.apk`

## Install

```bash
adb install -r build/SingularityWorkspace-debug.apk
```

Or copy the APK to your phone and install directly.

## Configuration

### AI Provider

Open the app, go to **Settings**, and configure:

- **OpenAI**: `https://api.openai.com/v1` → `gpt-4o-mini`
- **Mistral**: `https://api.mistral.ai/v1` → `mistral-large-latest`
- **DeepSeek**: `https://api.deepseek.com/v1` → `deepseek-chat`
- **OpenRouter**: `https://openrouter.ai/api/v1` → `deepseek/deepseek-chat`

### Remote Workspace

For the full Singularity Workspace experience with code-server:

1. Deploy the remote workspace on an Ubuntu/Debian VM
2. Set SSH tunnel config in the app:
   - Server IP
   - SSH Username
   - SSH Port (default 22)
   - code-server Port (default 8080)
   - AI Gateway Port (default 8787)
3. Use `singularity tunnel` from Termux, or configure the app to start SSHService

### Local Shell Commands

In the Terminal, type:
```
$ ls -la
$ pwd
$ ps
$ /system/bin/sh -c "echo hello"
```

Or use AI mode:
```
[AI button] → type your question
```

## File Structure

```
SingularityWorkspaceApp/
├── AndroidManifest.xml
├── build-apk.sh
├── src/com/singularity/workspace/
│   ├── MainActivity.java
│   ├── TerminalActivity.java
│   ├── SettingsActivity.java
│   ├── FileManagerActivity.java
│   ├── SSHService.java
│   └── LocalServerService.java
├── res/
│   ├── values/
│   │   ├── styles.xml
│   │   ├── colors.xml
│   │   └── strings.xml
│   ├── layout/ (optional)
│   ├── drawable/ (optional)
│   └── mipmap-hdpi/ (optional)
├── assets/
│   └── www/ (optional web assets)
└── lib/arm64-v8a/ (optional native libs)
```

## Permissions

The app requests these Android permissions:

- `INTERNET` — AI API calls, remote connections
- `ACCESS_NETWORK_STATE` — Network status
- `READ_EXTERNAL_STORAGE` — File manager read
- `WRITE_EXTERNAL_STORAGE` — File manager write
- `MANAGE_EXTERNAL_STORAGE` — Full file access (Android 11+)
- `FOREGROUND_SERVICE` — Background SSH tunnel
- `WAKE_LOCK` — Keep connection alive
- `VIBRATE` — Haptic feedback
- `REQUEST_INSTALL_PACKAGES` — APK installation

## Integration with Singularity Workspace

This Android app is the **mobile control plane** for the Singularity Workspace ecosystem:

```
Android Phone
  └── SingularityWorkspace.apk
      ├── AI Chat → OpenAI/Mistral/DeepSeek API
      ├── Terminal → Local shell + AI queries
      ├── Files → Local storage browser
      └── Remote → SSH tunnel to VM

Remote VM (Oracle Cloud / VPS)
  ├── code-server:8080
  ├── AI Gateway:8787
  ├── Docker
  └── /opt/singularity/workspace
```

## License

MIT
