#!/usr/bin/env bash
set -euo pipefail

# Singularity Workspace APK Builder
# Builds a native Android APK using aapt2, javac, d8, zipalign, apksigner
# No Gradle/Android Studio required

APP_NAME="SingularityWorkspace"
PACKAGE="com.singularity.workspace"
VERSION_CODE="1"
VERSION_NAME="1.0.0"

# Directories
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUILD_DIR="$SCRIPT_DIR/build"
SRC_DIR="$SCRIPT_DIR/src"
RES_DIR="$SCRIPT_DIR/res"
ASSETS_DIR="$SCRIPT_DIR/assets"
KEYSTORE="$BUILD_DIR/debug.keystore"

# Android SDK paths (adjust these for your environment)
ANDROID_HOME="${ANDROID_HOME:-$HOME/android-sdk}"
PLATFORM="android-35"
PLATFORM_JAR="$ANDROID_HOME/platforms/$PLATFORM/android.jar"
BUILD_TOOLS="$ANDROID_HOME/build-tools/35.0.0"
AAPT2="$BUILD_TOOLS/aapt2"
D8="$BUILD_TOOLS/d8"
ZIPALIGN="$BUILD_TOOLS/zipalign"
APKSIGNER="$BUILD_TOOLS/apksigner"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}====================================================${NC}"
echo -e "${BLUE}  Singularity Workspace APK Builder${NC}"
echo -e "${BLUE}====================================================${NC}"
echo ""

# Check prerequisites
check_prereq() {
    local cmd="$1"
    local name="$2"
    if command -v "$cmd" >/dev/null 2>&1; then
        echo -e "${GREEN}✓${NC} $name: $(command -v "$cmd")"
    else
        echo -e "${RED}✗${NC} $name not found: $cmd"
        return 1
    fi
}

echo "[1/10] Checking prerequisites..."
MISSING=0
check_prereq java "Java" || MISSING=1
check_prereq "$AAPT2" "aapt2" || MISSING=1
check_prereq "$D8" "d8" || MISSING=1
check_prereq "$ZIPALIGN" "zipalign" || MISSING=1
check_prereq "$APKSIGNER" "apksigner" || MISSING=1

if [ ! -f "$PLATFORM_JAR" ]; then
    echo -e "${RED}✗${NC} Platform JAR not found: $PLATFORM_JAR"
    MISSING=1
fi

if [ "$MISSING" -eq 1 ]; then
    echo ""
    echo -e "${RED}Missing prerequisites. Install Android SDK first.${NC}"
    echo "Run: sdkmanager 'platform-tools' 'platforms;android-35' 'build-tools;35.0.0'"
    exit 1
fi

# Clean and create build directories
echo ""
echo "[2/10] Preparing build directories..."
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/classes" "$BUILD_DIR/dex" "$BUILD_DIR/compiled" "$BUILD_DIR/generated"

# Compile resources with aapt2
echo ""
echo "[3/10] Compiling resources with aapt2..."
"$AAPT2" compile     --dir "$RES_DIR"     -o "$BUILD_DIR/compiled/resources.zip"     --verbose 2>/dev/null || true

# Link resources
echo ""
echo "[4/10] Linking resources..."
"$AAPT2" link     -o "$BUILD_DIR/unsigned.apk"     -I "$PLATFORM_JAR"     --manifest "$SCRIPT_DIR/AndroidManifest.xml"     "$BUILD_DIR/compiled/resources.zip"     --java "$BUILD_DIR/generated"     --auto-add-overlay     -A "$ASSETS_DIR"     --package-id 0x7f     --version-code "$VERSION_CODE"     --version-name "$VERSION_NAME"

echo -e "${GREEN}✓${NC} Resources linked"

# Compile Java sources
echo ""
echo "[5/10] Compiling Java sources..."

# Find all Java files
find "$SRC_DIR" "$BUILD_DIR/generated" -name "*.java" > "$BUILD_DIR/sources.txt"

# Compile with javac
javac -source 17 -target 17     -bootclasspath "$PLATFORM_JAR"     -d "$BUILD_DIR/classes"     @$BUILD_DIR/sources.txt

echo -e "${GREEN}✓${NC} Java compilation complete"

# Convert to DEX
echo ""
echo "[6/10] Converting to DEX..."
CLASS_FILES=$(find "$BUILD_DIR/classes" -name "*.class" | tr '\n' ' ')

if [ -n "$CLASS_FILES" ]; then
    "$D8"         --lib "$PLATFORM_JAR"         --output "$BUILD_DIR/dex"         $CLASS_FILES
    echo -e "${GREEN}✓${NC} DEX conversion complete"
else
    echo -e "${YELLOW}!${NC} No class files found, skipping D8"
fi

# Add DEX to APK
echo ""
echo "[7/10] Adding DEX to APK..."
if [ -f "$BUILD_DIR/dex/classes.dex" ]; then
    cd "$BUILD_DIR/dex"
    zip -q "$BUILD_DIR/unsigned.apk" classes.dex
    cd "$SCRIPT_DIR"
    echo -e "${GREEN}✓${NC} DEX added to APK"
else
    echo -e "${YELLOW}!${NC} No classes.dex found"
fi

# Generate debug keystore
echo ""
echo "[8/10] Generating debug keystore..."
if [ ! -f "$KEYSTORE" ]; then
    keytool -genkeypair         -keystore "$KEYSTORE"         -storepass android         -keypass android         -alias androiddebugkey         -keyalg RSA         -keysize 2048         -validity 10000         -dname "CN=Android Debug,O=Android,C=US"         >/dev/null 2>&1
    echo -e "${GREEN}✓${NC} Keystore created"
else
    echo -e "${GREEN}✓${NC} Using existing keystore"
fi

# Align APK
echo ""
echo "[9/10] Aligning APK..."
"$ZIPALIGN" -f 4     "$BUILD_DIR/unsigned.apk"     "$BUILD_DIR/aligned.apk"

echo -e "${GREEN}✓${NC} APK aligned"

# Sign APK
echo ""
echo "[10/10] Signing APK..."
"$APKSIGNER" sign     --ks "$KEYSTORE"     --ks-pass pass:android     --key-pass pass:android     --out "$BUILD_DIR/${APP_NAME}-debug.apk"     "$BUILD_DIR/aligned.apk"

# Verify
"$APKSIGNER" verify "$BUILD_DIR/${APP_NAME}-debug.apk"

echo ""
echo -e "${GREEN}====================================================${NC}"
echo -e "${GREEN}  Build Complete!${NC}"
echo -e "${GREEN}====================================================${NC}"
echo ""
echo "APK: $BUILD_DIR/${APP_NAME}-debug.apk"
echo "Package: $PACKAGE"
echo "Version: $VERSION_NAME ($VERSION_CODE)"
echo ""
echo "Install to device:"
echo "  adb install -r $BUILD_DIR/${APP_NAME}-debug.apk"
echo ""
echo "Or copy to phone and install directly."
echo ""

# Show APK info
if command -v aapt >/dev/null 2>&1; then
    echo "APK Info:"
    aapt dump badging "$BUILD_DIR/${APP_NAME}-debug.apk" | head -5
fi
