#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

echo "===================================================="
echo "  Singularity Workspace APK Builder for Termux"
echo "===================================================="
echo ""

# Install dependencies
echo "[1/6] Installing dependencies..."
pkg update -y
pkg install -y openjdk-17 gradle git wget unzip

# Setup Android SDK
echo ""
echo "[2/6] Setting up Android SDK..."
export ANDROID_HOME="$HOME/android-sdk"
mkdir -p "$ANDROID_HOME/cmdline-tools"

if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
    cd /tmp
    wget -q "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" -O cmdline-tools.zip
    unzip -q cmdline-tools.zip
    mv cmdline-tools "$ANDROID_HOME/cmdline-tools/latest"
fi

export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/build-tools/35.0.0:$PATH"

# Install SDK packages
yes | sdkmanager --licenses >/dev/null 2>&1 || true
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0" "cmdline-tools;latest" 2>/dev/null || true

# Download or create project
echo ""
echo "[3/6] Setting up project..."
PROJECT_DIR="$HOME/SingularityWorkspaceApp"
mkdir -p "$PROJECT_DIR"

# If you have the project files locally, copy them
# Otherwise, create minimal structure here
cd "$PROJECT_DIR"

# Create minimal AndroidManifest if not present
if [ ! -f AndroidManifest.xml ]; then
    cat > AndroidManifest.xml <<'EOF'
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.singularity.workspace"
    android:versionCode="1"
    android:versionName="1.0.0">
    <uses-sdk android:minSdkVersion="26" android:targetSdkVersion="35" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    <application
        android:label="Singularity Workspace"
        android:theme="@style/AppTheme"
        android:allowBackup="true"
        android:usesCleartextTraffic="true">
        <activity android:name=".MainActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
EOF
fi

# Create minimal resources
mkdir -p res/values
cat > res/values/styles.xml <<'EOF'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="android:style/Theme.Material.Light.NoActionBar">
        <item name="android:colorPrimary">#0f172a</item>
        <item name="android:colorPrimaryDark">#020617</item>
        <item name="android:colorAccent">#2563EB</item>
        <item name="android:windowBackground">#020617</item>
    </style>
</resources>
EOF

# Create minimal MainActivity
mkdir -p src/com/singularity/workspace
cat > src/com/singularity/workspace/MainActivity.java <<'EOF'
package com.singularity.workspace;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(0xFF020617);
        layout.setPadding(48, 48, 48, 48);

        TextView title = new TextView(this);
        title.setText("Singularity Workspace");
        title.setTextColor(0xFF38bdf8);
        title.setTextSize(24);
        layout.addView(title);

        TextView body = new TextView(this);
        body.setText("\nAI-powered development environment\n\nFeatures:\n- AI Chat\n- Terminal\n- File Manager\n- Remote Workspace\n\nConfigure in Settings.");
        body.setTextColor(0xFFe2e8f0);
        body.setTextSize(14);
        layout.addView(body);

        setContentView(layout);
    }
}
EOF

# Build script
echo ""
echo "[4/6] Creating build script..."
cat > build-apk.sh <<'BUILDEOF'
#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

APP_NAME="SingularityWorkspace"
PACKAGE="com.singularity.workspace"
BUILD_DIR="build"
SRC_DIR="src"
RES_DIR="res"
ANDROID_HOME="${ANDROID_HOME:-$HOME/android-sdk}"
PLATFORM="android-35"
PLATFORM_JAR="$ANDROID_HOME/platforms/$PLATFORM/android.jar"
BUILD_TOOLS="$ANDROID_HOME/build-tools/35.0.0"
AAPT2="$BUILD_TOOLS/aapt2"
D8="$BUILD_TOOLS/d8"
ZIPALIGN="$BUILD_TOOLS/zipalign"
APKSIGNER="$BUILD_TOOLS/apksigner"

rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/classes" "$BUILD_DIR/dex" "$BUILD_DIR/compiled" "$BUILD_DIR/generated"

echo "Compiling resources..."
"$AAPT2" compile --dir "$RES_DIR" -o "$BUILD_DIR/compiled/resources.zip" || true

echo "Linking resources..."
"$AAPT2" link     -o "$BUILD_DIR/unsigned.apk"     -I "$PLATFORM_JAR"     --manifest AndroidManifest.xml     "$BUILD_DIR/compiled/resources.zip"     --java "$BUILD_DIR/generated"     --auto-add-overlay     --version-code 1     --version-name "1.0.0"

echo "Compiling Java..."
find "$SRC_DIR" "$BUILD_DIR/generated" -name "*.java" > "$BUILD_DIR/sources.txt"
javac -source 17 -target 17     -bootclasspath "$PLATFORM_JAR"     -d "$BUILD_DIR/classes"     @$BUILD_DIR/sources.txt

echo "Converting to DEX..."
CLASS_FILES=$(find "$BUILD_DIR/classes" -name "*.class" | tr '\n' ' ')
"$D8" --lib "$PLATFORM_JAR" --output "$BUILD_DIR/dex" $CLASS_FILES

echo "Adding DEX to APK..."
cd "$BUILD_DIR/dex"
zip -q "$BUILD_DIR/unsigned.apk" classes.dex
cd ..

echo "Aligning APK..."
"$ZIPALIGN" -f 4 "$BUILD_DIR/unsigned.apk" "$BUILD_DIR/aligned.apk"

echo "Signing APK..."
if [ ! -f "$BUILD_DIR/debug.keystore" ]; then
    keytool -genkeypair -keystore "$BUILD_DIR/debug.keystore" -storepass android -keypass android -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US" >/dev/null 2>&1
fi

"$APKSIGNER" sign     --ks "$BUILD_DIR/debug.keystore"     --ks-pass pass:android     --key-pass pass:android     --out "${APP_NAME}-debug.apk"     "$BUILD_DIR/aligned.apk"

echo "Build complete: ${APP_NAME}-debug.apk"
BUILDEOF

chmod +x build-apk.sh

# Build
echo ""
echo "[5/6] Building APK..."
export ANDROID_HOME="$HOME/android-sdk"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/build-tools/35.0.0:$PATH"
./build-apk.sh

# Install
echo ""
echo "[6/6] Installing APK..."
if command -v adb >/dev/null 2>&1; then
    adb install -r "${APP_NAME}-debug.apk" || echo "Install via adb failed. Copy manually."
else
    echo "adb not found. APK location:"
    realpath "${APP_NAME}-debug.apk"
fi

echo ""
echo "===================================================="
echo "  Done!"
echo "===================================================="
echo "APK: $(realpath ${APP_NAME}-debug.apk)"
echo ""
echo "To install manually:"
echo "  cp $(realpath ${APP_NAME}-debug.apk) /sdcard/Download/"
echo "  Then open the file on your phone"
