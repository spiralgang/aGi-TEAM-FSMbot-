package com.singularity.workspace;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final String PREFS_NAME = "SingularityPrefs";
    private static final String PREF_AI_URL = "ai_base_url";
    private static final String PREF_AI_KEY = "ai_api_key";
    private static final String PREF_AI_MODEL = "ai_model";
    private static final String PREF_REMOTE_HOST = "remote_host";
    private static final String PREF_REMOTE_USER = "remote_user";
    private static final String PREF_REMOTE_PORT = "remote_port";
    private static final String PREF_CODE_PORT = "code_port";
    private static final String PREF_GATEWAY_PORT = "gateway_port";

    private ExecutorService executor;
    private Handler mainHandler;
    private SharedPreferences prefs;

    private TextView statusText;
    private TextView logOutput;
    private EditText promptInput;
    private LinearLayout chatContainer;
    private ScrollView chatScroll;
    private ToggleButton connectionToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        executor = Executors.newCachedThreadPool();
        mainHandler = new Handler(Looper.getMainLooper());
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        setContentView(createMainLayout());
        loadSavedConfig();
    }

    private LinearLayout createMainLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF020617);
        root.setPadding(32, 48, 32, 32);

        // Title
        TextView title = new TextView(this);
        title.setText("SINGULARITY WORKSPACE");
        title.setTextColor(0xFF38bdf8);
        title.setTextSize(22);
        title.setPadding(0, 0, 0, 8);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("AI-Powered Dev Environment");
        subtitle.setTextColor(0xFF64748b);
        subtitle.setTextSize(14);
        subtitle.setPadding(0, 0, 0, 24);
        root.addView(subtitle);

        // Status bar
        LinearLayout statusBar = new LinearLayout(this);
        statusBar.setOrientation(LinearLayout.HORIZONTAL);
        statusBar.setPadding(0, 0, 0, 16);

        statusText = new TextView(this);
        statusText.setText("\u26aa Disconnected");
        statusText.setTextColor(0xFF64748b);
        statusText.setTextSize(13);
        statusBar.addView(statusText);

        root.addView(statusBar);

        // Connection toggle
        connectionToggle = new ToggleButton(this);
        connectionToggle.setTextOn("Connected");
        connectionToggle.setTextOff("Connect to Remote");
        connectionToggle.setTextColor(0xFFf8fafc);
        connectionToggle.setBackgroundColor(0xFF1e293b);
        connectionToggle.setOnCheckedChangeListener((btn, isChecked) -> {
            if (isChecked) {
                testConnection();
            } else {
                updateStatus("Disconnected", 0xFF64748b);
            }
        });
        root.addView(connectionToggle);

        // Button grid
        LinearLayout buttonGrid = new LinearLayout(this);
        buttonGrid.setOrientation(LinearLayout.HORIZONTAL);
        buttonGrid.setPadding(0, 16, 0, 16);

        buttonGrid.addView(createActionButton("\u2328 Terminal", v -> openTerminal()));
        buttonGrid.addView(createActionButton("\u1F4C4 Files", v -> openFileManager()));
        buttonGrid.addView(createActionButton("\u2699 Settings", v -> openSettings()));

        root.addView(buttonGrid);

        // Quick action buttons
        LinearLayout quickGrid = new LinearLayout(this);
        quickGrid.setOrientation(LinearLayout.HORIZONTAL);
        quickGrid.setPadding(0, 0, 0, 16);

        quickGrid.addView(createActionButton("\u1F4BB Code Server", v -> openCodeServer()));
        quickGrid.addView(createActionButton("\u1F916 AI Chat", v -> scrollToChat()));
        quickGrid.addView(createActionButton("\u1F527 Tools", v -> showToolsMenu()));

        root.addView(quickGrid);

        // AI Chat section
        TextView chatLabel = new TextView(this);
        chatLabel.setText("AI CHAT");
        chatLabel.setTextColor(0xFF38bdf8);
        chatLabel.setTextSize(12);
        chatLabel.setPadding(0, 16, 0, 8);
        root.addView(chatLabel);

        chatScroll = new ScrollView(this);
        chatScroll.setBackgroundColor(0xFF0f172a);
        chatScroll.setPadding(16, 16, 16, 16);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f);
        chatScroll.setLayoutParams(scrollParams);

        chatContainer = new LinearLayout(this);
        chatContainer.setOrientation(LinearLayout.VERTICAL);
        chatScroll.addView(chatContainer);
        root.addView(chatScroll);

        // Input area
        LinearLayout inputBar = new LinearLayout(this);
        inputBar.setOrientation(LinearLayout.HORIZONTAL);
        inputBar.setPadding(0, 12, 0, 0);

        promptInput = new EditText(this);
        promptInput.setHint("Ask AI or type /cmd...");
        promptInput.setTextColor(0xFFe2e8f0);
        promptInput.setHintTextColor(0xFF475569);
        promptInput.setBackgroundColor(0xFF1e293b);
        promptInput.setPadding(20, 16, 20, 16);
        promptInput.setTextSize(14);
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
        promptInput.setLayoutParams(inputParams);
        inputBar.addView(promptInput);

        Button sendBtn = new Button(this);
        sendBtn.setText("\u25B6");
        sendBtn.setTextColor(0xFF38bdf8);
        sendBtn.setBackgroundColor(0xFF1e293b);
        sendBtn.setOnClickListener(v -> sendPrompt());
        inputBar.addView(sendBtn);

        root.addView(inputBar);

        // Local shell output
        TextView localLabel = new TextView(this);
        localLabel.setText("LOCAL SHELL");
        localLabel.setTextColor(0xFF4ade80);
        localLabel.setTextSize(12);
        localLabel.setPadding(0, 16, 0, 8);
        root.addView(localLabel);

        logOutput = new TextView(this);
        logOutput.setTextColor(0xFF4ade80);
        logOutput.setTextSize(11);
        logOutput.setBackgroundColor(0xFF0f172a);
        logOutput.setPadding(16, 16, 16, 16);
        logOutput.setMinLines(4);
        logOutput.setText("$ singularity-workspace v1.0.0\n$ Ready. Connect to remote or use local AI.\n$");
        root.addView(logOutput);

        return root;
    }

    private Button createActionButton(String text, View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(0xFFe2e8f0);
        btn.setBackgroundColor(0xFF1e293b);
        btn.setPadding(16, 24, 16, 24);
        btn.setTextSize(12);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
        params.setMargins(4, 4, 4, 4);
        btn.setLayoutParams(params);
        btn.setOnClickListener(listener);
        return btn;
    }

    private void addChatMessage(String role, String content) {
        TextView msg = new TextView(this);
        msg.setText(role + ": " + content);
        msg.setTextColor(role.equals("You") ? 0xFF38bdf8 : 0xFFe2e8f0);
        msg.setTextSize(13);
        msg.setPadding(8, 8, 8, 8);
        msg.setBackgroundColor(role.equals("You") ? 0xFF1e3a5f : 0xFF1e293b);
        chatContainer.addView(msg);
        chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
    }

    private void sendPrompt() {
        String text = promptInput.getText().toString().trim();
        if (text.isEmpty()) return;

        addChatMessage("You", text);
        promptInput.setText("");

        if (text.startsWith("/")) {
            handleCommand(text);
            return;
        }

        String aiUrl = prefs.getString(PREF_AI_URL, "https://api.openai.com/v1");
        String aiKey = prefs.getString(PREF_AI_KEY, "");
        String aiModel = prefs.getString(PREF_AI_MODEL, "gpt-4o-mini");

        if (aiKey.isEmpty()) {
            addChatMessage("System", "No API key configured. Go to Settings.");
            return;
        }

        executor.execute(() -> {
            try {
                String response = callAIChat(aiUrl, aiKey, aiModel, text);
                mainHandler.post(() -> addChatMessage("AI", response));
            } catch (Exception e) {
                mainHandler.post(() -> addChatMessage("Error", e.getMessage()));
            }
        });
    }

    private String callAIChat(String baseUrl, String apiKey, String model, String prompt) throws Exception {
        URL url = new URL(baseUrl + "/chat/completions");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(120000);

        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("temperature", 0.25);
        body.put("stream", false);

        JSONArray messages = new JSONArray();
        JSONObject msg = new JSONObject();
        msg.put("role", "user");
        msg.put("content", prompt);
        messages.put(msg);
        body.put("messages", messages);

        DataOutputStream out = new DataOutputStream(conn.getOutputStream());
        out.writeBytes(body.toString());
        out.flush();
        out.close();

        int status = conn.getResponseCode();
        BufferedReader reader;
        if (status >= 200 && status < 300) {
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        } else {
            reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        }

        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();

        if (status >= 200 && status < 300) {
            JSONObject json = new JSONObject(response.toString());
            JSONArray choices = json.getJSONArray("choices");
            if (choices.length() > 0) {
                return choices.getJSONObject(0).getJSONObject("message").getString("content");
            }
            return "No response from AI";
        } else {
            return "HTTP " + status + ": " + response.toString();
        }
    }

    private void handleCommand(String cmd) {
        String[] parts = cmd.substring(1).split(" ", 2);
        String action = parts[0];
        String args = parts.length > 1 ? parts[1] : "";

        switch (action) {
            case "shell":
                runLocalShell(args);
                break;
            case "clear":
                chatContainer.removeAllViews();
                break;
            case "help":
                addChatMessage("System", "Commands: /shell <cmd>, /clear, /help, /connect, /code");
                break;
            case "connect":
                testConnection();
                break;
            case "code":
                openCodeServer();
                break;
            default:
                addChatMessage("System", "Unknown command: " + action);
        }
    }

    private void runLocalShell(String command) {
        if (command.isEmpty()) {
            addChatMessage("System", "Usage: /shell <command>");
            return;
        }
        executor.execute(() -> {
            try {
                Process process = Runtime.getRuntime().exec(new String[]{"/system/bin/sh", "-c", command});
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                StringBuilder output = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }
                reader.close();

                BufferedReader errReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
                while ((line = errReader.readLine()) != null) {
                    output.append("ERR: ").append(line).append("\n");
                }
                errReader.close();

                process.waitFor();
                final String result = output.toString();
                mainHandler.post(() -> {
                    addChatMessage("Shell", result);
                    appendLog("$ " + command + "\n" + result);
                });
            } catch (Exception e) {
                mainHandler.post(() -> addChatMessage("Error", e.getMessage()));
            }
        });
    }

    private void testConnection() {
        String host = prefs.getString(PREF_REMOTE_HOST, "");
        if (host.isEmpty()) {
            updateStatus("No remote host configured", 0xFFf59e0b);
            connectionToggle.setChecked(false);
            return;
        }

        updateStatus("Testing...", 0xFFf59e0b);
        executor.execute(() -> {
            try {
                String gatewayUrl = "http://127.0.0.1:" + prefs.getString(PREF_GATEWAY_PORT, "8787") + "/health";
                URL url = new URL(gatewayUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                int status = conn.getResponseCode();
                conn.disconnect();

                if (status == 200) {
                    mainHandler.post(() -> updateStatus("\u26AB Connected (tunnel active)", 0xFF22c55e));
                } else {
                    mainHandler.post(() -> updateStatus("Gateway unreachable", 0xFFef4444));
                }
            } catch (Exception e) {
                mainHandler.post(() -> {
                    updateStatus("Tunnel not active", 0xFFf59e0b);
                    connectionToggle.setChecked(false);
                });
            }
        });
    }

    private void updateStatus(String text, int color) {
        statusText.setText(text);
        statusText.setTextColor(color);
    }

    private void appendLog(String text) {
        logOutput.append(text);
    }

    private void openTerminal() {
        Intent intent = new Intent(this, TerminalActivity.class);
        startActivity(intent);
    }

    private void openFileManager() {
        Intent intent = new Intent(this, FileManagerActivity.class);
        startActivity(intent);
    }

    private void openSettings() {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }

    private void openCodeServer() {
        String codePort = prefs.getString(PREF_CODE_PORT, "8080");
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(android.net.Uri.parse("http://127.0.0.1:" + codePort));
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No browser found. Start tunnel first.", Toast.LENGTH_LONG).show();
        }
    }

    private void scrollToChat() {
        chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
    }

    private void showToolsMenu() {
        new AlertDialog.Builder(this)
            .setTitle("Tools")
            .setItems(new String[]{"SSH Connect", "AI Gateway Test", "Clear Chat", "About"}, (dialog, which) -> {
                switch (which) {
                    case 0: openTerminal(); break;
                    case 1: testConnection(); break;
                    case 2: chatContainer.removeAllViews(); break;
                    case 3: showAbout(); break;
                }
            })
            .show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
            .setTitle("Singularity Workspace v1.0.0")
            .setMessage("AI-powered development environment for Android.\n\n" +
                "Features:\n" +
                "- OpenAI-compatible AI chat\n" +
                "- Remote workspace via SSH tunnel\n" +
                "- Local shell execution\n" +
                "- File manager\n" +
                "- code-server integration\n\n" +
                "Built for Android aarch64.")
            .setPositiveButton("OK", null)
            .show();
    }

    private void loadSavedConfig() {
        // Config loaded from SharedPreferences when needed
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
