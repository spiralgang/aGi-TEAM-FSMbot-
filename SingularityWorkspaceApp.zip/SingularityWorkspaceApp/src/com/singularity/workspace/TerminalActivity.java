package com.singularity.workspace;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.method.ScrollingMovementMethod;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONArray;
import org.json.JSONObject;

public class TerminalActivity extends Activity {

    private static final String PREFS_NAME = "SingularityPrefs";
    private ExecutorService executor;
    private Handler mainHandler;
    private SharedPreferences prefs;

    private TextView terminalOutput;
    private EditText commandInput;
    private ScrollView terminalScroll;
    private Process shellProcess;
    private OutputStream shellInput;
    private BufferedReader shellOutput;
    private BufferedReader shellError;
    private boolean shellRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        executor = Executors.newCachedThreadPool();
        mainHandler = new Handler(Looper.getMainLooper());
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        setContentView(createTerminalLayout());
        startLocalShell();
    }

    private LinearLayout createTerminalLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF020617);

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setBackgroundColor(0xFF0f172a);
        header.setPadding(24, 24, 24, 24);

        TextView title = new TextView(this);
        title.setText("\u2328 Terminal");
        title.setTextColor(0xFF38bdf8);
        title.setTextSize(18);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
        title.setLayoutParams(titleParams);
        header.addView(title);

        Button backBtn = new Button(this);
        backBtn.setText("\u2190");
        backBtn.setTextColor(0xFFe2e8f0);
        backBtn.setBackgroundColor(0xFF1e293b);
        backBtn.setOnClickListener(v -> finish());
        header.addView(backBtn);

        root.addView(header);

        // Terminal output
        terminalScroll = new ScrollView(this);
        terminalScroll.setBackgroundColor(0xFF020617);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f);
        terminalScroll.setLayoutParams(scrollParams);

        terminalOutput = new TextView(this);
        terminalOutput.setTextColor(0xFF4ade80);
        terminalOutput.setTextSize(12);
        terminalOutput.setPadding(24, 24, 24, 24);
        terminalOutput.setTypeface(android.graphics.Typeface.MONOSPACE);
        terminalOutput.setMovementMethod(new ScrollingMovementMethod());
        terminalScroll.addView(terminalOutput);
        root.addView(terminalScroll);

        // Command input bar
        LinearLayout inputBar = new LinearLayout(this);
        inputBar.setOrientation(LinearLayout.HORIZONTAL);
        inputBar.setBackgroundColor(0xFF0f172a);
        inputBar.setPadding(16, 16, 16, 16);

        commandInput = new EditText(this);
        commandInput.setHint("$ type command...");
        commandInput.setTextColor(0xFFe2e8f0);
        commandInput.setHintTextColor(0xFF475569);
        commandInput.setBackgroundColor(0xFF1e293b);
        commandInput.setPadding(20, 16, 20, 16);
        commandInput.setTextSize(14);
        commandInput.setTypeface(android.graphics.Typeface.MONOSPACE);
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
        commandInput.setLayoutParams(inputParams);
        commandInput.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN) {
                executeCommand();
                return true;
            }
            return false;
        });
        inputBar.addView(commandInput);

        Button runBtn = new Button(this);
        runBtn.setText("\u25B6");
        runBtn.setTextColor(0xFF38bdf8);
        runBtn.setBackgroundColor(0xFF1e293b);
        runBtn.setOnClickListener(v -> executeCommand());
        inputBar.addView(runBtn);

        root.addView(inputBar);

        // Quick buttons
        LinearLayout quickBar = new LinearLayout(this);
        quickBar.setOrientation(LinearLayout.HORIZONTAL);
        quickBar.setBackgroundColor(0xFF0f172a);
        quickBar.setPadding(8, 8, 8, 8);

        quickBar.addView(createQuickBtn("ls", "ls -la"));
        quickBar.addView(createQuickBtn("pwd", "pwd"));
        quickBar.addView(createQuickBtn("whoami", "whoami"));
        quickBar.addView(createQuickBtn("ps", "ps"));
        quickBar.addView(createQuickBtn("clear", "\u00A7CLEAR"));
        quickBar.addView(createQuickBtn("AI", "\u00A7AI"));

        root.addView(quickBar);

        return root;
    }

    private Button createQuickBtn(String label, final String cmd) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setTextColor(0xFF94a3b8);
        btn.setBackgroundColor(0xFF1e293b);
        btn.setTextSize(11);
        btn.setPadding(12, 8, 12, 8);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
        params.setMargins(4, 4, 4, 4);
        btn.setLayoutParams(params);
        btn.setOnClickListener(v -> {
            if (cmd.equals("\u00A7CLEAR")) {
                terminalOutput.setText("");
            } else if (cmd.equals("\u00A7AI")) {
                commandInput.setHint("Ask AI...");
                commandInput.setTag("AI_MODE");
            } else {
                commandInput.setText(cmd);
                executeCommand();
            }
        });
        return btn;
    }

    private void startLocalShell() {
        executor.execute(() -> {
            try {
                shellProcess = Runtime.getRuntime().exec("/system/bin/sh");
                shellInput = shellProcess.getOutputStream();
                shellOutput = new BufferedReader(new InputStreamReader(shellProcess.getInputStream()));
                shellError = new BufferedReader(new InputStreamReader(shellProcess.getErrorStream()));
                shellRunning = true;

                // Read stdout
                executor.execute(() -> {
                    try {
                        String line;
                        while (shellRunning && (line = shellOutput.readLine()) != null) {
                            final String output = line;
                            mainHandler.post(() -> appendTerminalOutput(output + "\n"));
                        }
                    } catch (Exception e) {
                        if (shellRunning) {
                            mainHandler.post(() -> appendTerminalOutput("\n[stdout closed]\n"));
                        }
                    }
                });

                // Read stderr
                executor.execute(() -> {
                    try {
                        String line;
                        while (shellRunning && (line = shellError.readLine()) != null) {
                            final String output = line;
                            mainHandler.post(() -> appendTerminalOutput("[ERR] " + output + "\n", 0xFFf87171));
                        }
                    } catch (Exception e) {
                        if (shellRunning) {
                            mainHandler.post(() -> appendTerminalOutput("\n[stderr closed]\n"));
                        }
                    }
                });

                mainHandler.post(() -> {
                    appendTerminalOutput("Singularity Terminal v1.0.0\n");
                    appendTerminalOutput("Android " + android.os.Build.VERSION.RELEASE + " / " + android.os.Build.CPU_ABI + "\n");
                    appendTerminalOutput("Type commands or use quick buttons.\n");
                    appendTerminalOutput("Use AI button for AI chat mode.\n\n");
                });

            } catch (Exception e) {
                mainHandler.post(() -> {
                    appendTerminalOutput("Failed to start shell: " + e.getMessage() + "\n", 0xFFef4444);
                });
            }
        });
    }

    private void executeCommand() {
        String cmd = commandInput.getText().toString().trim();
        if (cmd.isEmpty()) return;

        commandInput.setText("");

        // Check if AI mode
        if ("AI_MODE".equals(commandInput.getTag())) {
            commandInput.setTag(null);
            commandInput.setHint("$ type command...");
            runAIQuery(cmd);
            return;
        }

        appendTerminalOutput("$ " + cmd + "\n", 0xFF38bdf8);

        if (shellRunning && shellInput != null) {
            try {
                shellInput.write((cmd + "\n").getBytes());
                shellInput.flush();
            } catch (Exception e) {
                appendTerminalOutput("[Error] " + e.getMessage() + "\n", 0xFFef4444);
            }
        } else {
            appendTerminalOutput("[Shell not running]\n", 0xFFf59e0b);
        }
    }

    private void runAIQuery(String prompt) {
        String aiUrl = prefs.getString("ai_base_url", "https://api.openai.com/v1");
        String aiKey = prefs.getString("ai_api_key", "");
        String aiModel = prefs.getString("ai_model", "gpt-4o-mini");

        if (aiKey.isEmpty()) {
            appendTerminalOutput("[AI] No API key configured. Go to Settings.\n", 0xFFf59e0b);
            return;
        }

        appendTerminalOutput("[AI] Thinking...\n", 0xFFc084fc);

        executor.execute(() -> {
            try {
                URL url = new URL(aiUrl + "/chat/completions");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Authorization", "Bearer " + aiKey);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
                conn.setConnectTimeout(30000);
                conn.setReadTimeout(120000);

                JSONObject body = new JSONObject();
                body.put("model", aiModel);
                body.put("temperature", 0.25);
                body.put("stream", false);

                JSONArray messages = new JSONArray();
                JSONObject msg = new JSONObject();
                msg.put("role", "user");
                msg.put("content", prompt);
                messages.put(msg);
                body.put("messages", messages);

                DataOutputStream out = new DataOutputStream(conn.getOutputStream());
                out.writeBytes(body.toString());
                out.flush();
                out.close();

                int status = conn.getResponseCode();
                BufferedReader reader;
                if (status >= 200 && status < 300) {
                    reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                } else {
                    reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
                }

                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                if (status >= 200 && status < 300) {
                    JSONObject json = new JSONObject(response.toString());
                    JSONArray choices = json.getJSONArray("choices");
                    if (choices.length() > 0) {
                        String content = choices.getJSONObject(0).getJSONObject("message").getString("content");
                        mainHandler.post(() -> appendTerminalOutput("[AI] " + content + "\n\n", 0xFFc084fc));
                    }
                } else {
                    mainHandler.post(() -> appendTerminalOutput("[AI Error] HTTP " + status + "\n", 0xFFef4444));
                }
            } catch (Exception e) {
                mainHandler.post(() -> appendTerminalOutput("[AI Error] " + e.getMessage() + "\n", 0xFFef4444));
            }
        });
    }

    private void appendTerminalOutput(String text) {
        appendTerminalOutput(text, 0xFF4ade80);
    }

    private void appendTerminalOutput(String text, int color) {
        android.text.SpannableStringBuilder ssb = new android.text.SpannableStringBuilder(text);
        android.text.style.ForegroundColorSpan span = new android.text.style.ForegroundColorSpan(color);
        ssb.setSpan(span, 0, text.length(), android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        terminalOutput.append(ssb);
        terminalScroll.post(() -> terminalScroll.fullScroll(ScrollView.FOCUS_DOWN));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        shellRunning = false;
        if (shellProcess != null) {
            shellProcess.destroy();
        }
        executor.shutdown();
    }
}
