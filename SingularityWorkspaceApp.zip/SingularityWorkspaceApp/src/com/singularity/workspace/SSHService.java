package com.singularity.workspace;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SSHService extends Service {

    private static final String TAG = "SSHService";
    private static final String CHANNEL_ID = "singularity_ssh";
    private ExecutorService executor;
    private Process sshProcess;
    private boolean running = false;

    @Override
    public void onCreate() {
        super.onCreate();
        executor = Executors.newSingleThreadExecutor();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (running) {
            return START_STICKY;
        }

        SharedPreferences prefs = getSharedPreferences("SingularityPrefs", MODE_PRIVATE);
        String host = prefs.getString("remote_host", "");
        String user = prefs.getString("remote_user", "singularity");
        String port = prefs.getString("remote_port", "22");
        String codePort = prefs.getString("code_port", "8080");
        String gatewayPort = prefs.getString("gateway_port", "8787");

        if (host.isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification notification = new Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Singularity SSH Tunnel")
            .setContentText("Connected to " + host)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build();

        startForeground(1, notification);

        executor.execute(() -> {
            try {
                running = true;
                String[] cmd = {
                    "/system/bin/ssh",
                    "-N",
                    "-p", port,
                    "-L", codePort + ":127.0.0.1:" + codePort,
                    "-L", gatewayPort + ":127.0.0.1:" + gatewayPort,
                    user + "@" + host
                };

                sshProcess = Runtime.getRuntime().exec(cmd);
                BufferedReader reader = new BufferedReader(new InputStreamReader(sshProcess.getErrorStream()));
                String line;
                while (running && (line = reader.readLine()) != null) {
                    Log.d(TAG, "SSH: " + line);
                }
                sshProcess.waitFor();
            } catch (Exception e) {
                Log.e(TAG, "SSH error: " + e.getMessage());
            } finally {
                running = false;
                stopSelf();
            }
        });

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        if (sshProcess != null) {
            sshProcess.destroy();
        }
        executor.shutdown();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Singularity SSH",
                NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
}
