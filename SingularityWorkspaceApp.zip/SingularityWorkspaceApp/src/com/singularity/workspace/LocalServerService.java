package com.singularity.workspace;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LocalServerService extends Service {

    private static final String TAG = "LocalServer";
    private static final int PORT = 9090;
    private ExecutorService executor;
    private ServerSocket serverSocket;
    private boolean running = false;

    @Override
    public void onCreate() {
        super.onCreate();
        executor = Executors.newCachedThreadPool();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (running) return START_STICKY;

        executor.execute(() -> {
            try {
                serverSocket = new ServerSocket(PORT);
                running = true;
                Log.d(TAG, "Local server on port " + PORT);

                while (running) {
                    Socket client = serverSocket.accept();
                    executor.execute(() -> handleClient(client));
                }
            } catch (IOException e) {
                Log.e(TAG, "Server error: " + e.getMessage());
            }
        });

        return START_STICKY;
    }

    private void handleClient(Socket client) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
            OutputStream out = client.getOutputStream();

            String line = reader.readLine();
            if (line == null) return;

            String path = "/";
            if (line.startsWith("GET ")) {
                path = line.split(" ")[1];
            }

            String response = serveAsset(path);
            out.write(response.getBytes());
            out.flush();
            out.close();
            reader.close();
            client.close();
        } catch (IOException e) {
            Log.e(TAG, "Client error: " + e.getMessage());
        }
    }

    private String serveAsset(String path) {
        if (path.equals("/") || path.equals("/index.html")) {
            return "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n" +
                "<html><head><title>Singularity</title></head>" +
                "<body style='background:#020617;color:#e2e8f0;font-family:monospace;padding:40px;'>" +
                "<h1>Singularity Workspace</h1>" +
                "<p>Local server running on port " + PORT + "</p>" +
                "<p>Use the Android app for full functionality.</p>" +
                "</body></html>";
        }
        return "HTTP/1.1 404 Not Found\r\n\r\nNot Found";
    }

    @Override
    public void onDestroy() {
        running = false;
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (IOException e) {
            Log.e(TAG, "Close error: " + e.getMessage());
        }
        executor.shutdown();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
