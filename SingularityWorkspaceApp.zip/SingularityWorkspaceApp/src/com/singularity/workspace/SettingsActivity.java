package com.singularity.workspace;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {

    private static final String PREFS_NAME = "SingularityPrefs";
    private SharedPreferences prefs;

    private EditText aiUrlInput;
    private EditText aiKeyInput;
    private EditText aiModelInput;
    private EditText remoteHostInput;
    private EditText remoteUserInput;
    private EditText remotePortInput;
    private EditText codePortInput;
    private EditText gatewayPortInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        setContentView(createSettingsLayout());
        loadSettings();
    }

    private LinearLayout createSettingsLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF020617);

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setBackgroundColor(0xFF0f172a);
        header.setPadding(24, 24, 24, 24);

        TextView title = new TextView(this);
        title.setText("\u2699 Settings");
        title.setTextColor(0xFF38bdf8);
        title.setTextSize(18);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
        title.setLayoutParams(titleParams);
        header.addView(title);

        Button backBtn = new Button(this);
        backBtn.setText("\u2190");
        backBtn.setTextColor(0xFFe2e8f0);
        backBtn.setBackgroundColor(0xFF1e293b);
        backBtn.setOnClickListener(v -> finish());
        header.addView(backBtn);

        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(24, 24, 24, 24);

        // AI Section
        container.addView(createSectionLabel("AI PROVIDER"));
        aiUrlInput = createInput("Base URL (e.g. https://api.openai.com/v1)");
        container.addView(aiUrlInput);
        aiKeyInput = createInput("API Key");
        aiKeyInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        container.addView(aiKeyInput);
        aiModelInput = createInput("Model (e.g. gpt-4o-mini)");
        container.addView(aiModelInput);

        // Remote Section
        container.addView(createSectionLabel("REMOTE WORKSPACE"));
        remoteHostInput = createInput("Server IP/Hostname");
        container.addView(remoteHostInput);
        remoteUserInput = createInput("SSH Username");
        container.addView(remoteUserInput);
        remotePortInput = createInput("SSH Port (default 22)");
        remotePortInput.setText("22");
        container.addView(remotePortInput);
        codePortInput = createInput("code-server Port (default 8080)");
        codePortInput.setText("8080");
        container.addView(codePortInput);
        gatewayPortInput = createInput("AI Gateway Port (default 8787)");
        gatewayPortInput.setText("8787");
        container.addView(gatewayPortInput);

        // Preset buttons
        container.addView(createSectionLabel("QUICK PRESETS"));
        LinearLayout presetBar = new LinearLayout(this);
        presetBar.setOrientation(LinearLayout.HORIZONTAL);

        presetBar.addView(createPresetBtn("OpenAI", () -> {
            aiUrlInput.setText("https://api.openai.com/v1");
            aiModelInput.setText("gpt-4o-mini");
        }));
        presetBar.addView(createPresetBtn("Mistral", () -> {
            aiUrlInput.setText("https://api.mistral.ai/v1");
            aiModelInput.setText("mistral-large-latest");
        }));
        presetBar.addView(createPresetBtn("DeepSeek", () -> {
            aiUrlInput.setText("https://api.deepseek.com/v1");
            aiModelInput.setText("deepseek-chat");
        }));
        presetBar.addView(createPresetBtn("OpenRouter", () -> {
            aiUrlInput.setText("https://openrouter.ai/api/v1");
            aiModelInput.setText("deepseek/deepseek-chat");
        }));

        container.addView(presetBar);

        // Save button
        Button saveBtn = new Button(this);
        saveBtn.setText("SAVE SETTINGS");
        saveBtn.setTextColor(0xFF020617);
        saveBtn.setBackgroundColor(0xFF22c55e);
        saveBtn.setPadding(24, 24, 24, 24);
        saveBtn.setOnClickListener(v -> saveSettings());
        container.addView(saveBtn);

        scroll.addView(container);
        root.addView(scroll);

        return root;
    }

    private TextView createSectionLabel(String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(0xFF38bdf8);
        label.setTextSize(12);
        label.setPadding(0, 24, 0, 12);
        return label;
    }

    private EditText createInput(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setTextColor(0xFFe2e8f0);
        input.setHintTextColor(0xFF475569);
        input.setBackgroundColor(0xFF1e293b);
        input.setPadding(20, 16, 20, 16);
        input.setTextSize(14);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, 12);
        input.setLayoutParams(params);
        return input;
    }

    private Button createPresetBtn(String label, Runnable action) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setTextColor(0xFFe2e8f0);
        btn.setBackgroundColor(0xFF1e293b);
        btn.setTextSize(11);
        btn.setPadding(12, 16, 12, 16);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
        params.setMargins(4, 4, 4, 4);
        btn.setLayoutParams(params);
        btn.setOnClickListener(v -> action.run());
        return btn;
    }

    private void loadSettings() {
        aiUrlInput.setText(prefs.getString("ai_base_url", "https://api.openai.com/v1"));
        aiKeyInput.setText(prefs.getString("ai_api_key", ""));
        aiModelInput.setText(prefs.getString("ai_model", "gpt-4o-mini"));
        remoteHostInput.setText(prefs.getString("remote_host", ""));
        remoteUserInput.setText(prefs.getString("remote_user", "singularity"));
        remotePortInput.setText(prefs.getString("remote_port", "22"));
        codePortInput.setText(prefs.getString("code_port", "8080"));
        gatewayPortInput.setText(prefs.getString("gateway_port", "8787"));
    }

    private void saveSettings() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("ai_base_url", aiUrlInput.getText().toString().trim());
        editor.putString("ai_api_key", aiKeyInput.getText().toString().trim());
        editor.putString("ai_model", aiModelInput.getText().toString().trim());
        editor.putString("remote_host", remoteHostInput.getText().toString().trim());
        editor.putString("remote_user", remoteUserInput.getText().toString().trim());
        editor.putString("remote_port", remotePortInput.getText().toString().trim());
        editor.putString("code_port", codePortInput.getText().toString().trim());
        editor.putString("gateway_port", gatewayPortInput.getText().toString().trim());
        editor.apply();

        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
        finish();
    }
}
