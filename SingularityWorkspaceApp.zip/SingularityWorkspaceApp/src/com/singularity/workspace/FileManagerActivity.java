package com.singularity.workspace;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;

public class FileManagerActivity extends Activity {

    private LinearLayout fileListContainer;
    private ScrollView fileScroll;
    private TextView pathLabel;
    private File currentDir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(createFileManagerLayout());

        File external = Environment.getExternalStorageDirectory();
        currentDir = external;
        refreshFileList();
    }

    private LinearLayout createFileManagerLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF020617);

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setBackgroundColor(0xFF0f172a);
        header.setPadding(24, 24, 24, 24);

        TextView title = new TextView(this);
        title.setText("\u1F4C1 File Manager");
        title.setTextColor(0xFF38bdf8);
        title.setTextSize(18);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
        title.setLayoutParams(titleParams);
        header.addView(title);

        Button backBtn = new Button(this);
        backBtn.setText("\u2190");
        backBtn.setTextColor(0xFFe2e8f0);
        backBtn.setBackgroundColor(0xFF1e293b);
        backBtn.setOnClickListener(v -> finish());
        header.addView(backBtn);

        root.addView(header);

        // Path label
        pathLabel = new TextView(this);
        pathLabel.setTextColor(0xFF94a3b8);
        pathLabel.setTextSize(11);
        pathLabel.setPadding(24, 12, 24, 12);
        pathLabel.setBackgroundColor(0xFF0f172a);
        root.addView(pathLabel);

        // File list
        fileScroll = new ScrollView(this);
        fileScroll.setBackgroundColor(0xFF020617);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f);
        fileScroll.setLayoutParams(scrollParams);

        fileListContainer = new LinearLayout(this);
        fileListContainer.setOrientation(LinearLayout.VERTICAL);
        fileListContainer.setPadding(16, 16, 16, 16);
        fileScroll.addView(fileListContainer);
        root.addView(fileScroll);

        // Action bar
        LinearLayout actionBar = new LinearLayout(this);
        actionBar.setOrientation(LinearLayout.HORIZONTAL);
        actionBar.setBackgroundColor(0xFF0f172a);
        actionBar.setPadding(8, 8, 8, 8);

        actionBar.addView(createActionBtn("Up", v -> goUp()));
        actionBar.addView(createActionBtn("New Dir", v -> createNewDirectory()));
        actionBar.addView(createActionBtn("New File", v -> createNewFile()));
        actionBar.addView(createActionBtn("Refresh", v -> refreshFileList()));

        root.addView(actionBar);

        return root;
    }

    private Button createActionBtn(String label, View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setTextColor(0xFFe2e8f0);
        btn.setBackgroundColor(0xFF1e293b);
        btn.setTextSize(11);
        btn.setPadding(12, 16, 12, 16);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
        params.setMargins(4, 4, 4, 4);
        btn.setLayoutParams(params);
        btn.setOnClickListener(listener);
        return btn;
    }

    private void refreshFileList() {
        fileListContainer.removeAllViews();
        pathLabel.setText(currentDir.getAbsolutePath());

        File[] files = currentDir.listFiles();
        if (files == null) {
            TextView msg = new TextView(this);
            msg.setText("Cannot access directory");
            msg.setTextColor(0xFFef4444);
            msg.setPadding(16, 16, 16, 16);
            fileListContainer.addView(msg);
            return;
        }

        Arrays.sort(files, (a, b) -> {
            if (a.isDirectory() && !b.isDirectory()) return -1;
            if (!a.isDirectory() && b.isDirectory()) return 1;
            return a.getName().compareToIgnoreCase(b.getName());
        });

        for (File file : files) {
            addFileEntry(file);
        }
    }

    private void addFileEntry(File file) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(16, 12, 16, 12);
        row.setBackgroundColor(0xFF1e293b);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.setMargins(0, 4, 0, 4);
        row.setLayoutParams(rowParams);

        TextView icon = new TextView(this);
        icon.setText(file.isDirectory() ? "\u1F4C1" : "\u1F4C4");
        icon.setTextSize(18);
        icon.setPadding(0, 0, 16, 0);
        row.addView(icon);

        TextView name = new TextView(this);
        name.setText(file.getName());
        name.setTextColor(0xFFe2e8f0);
        name.setTextSize(14);
        LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
        name.setLayoutParams(nameParams);
        row.addView(name);

        TextView size = new TextView(this);
        size.setText(file.isDirectory() ? "dir" : formatSize(file.length()));
        size.setTextColor(0xFF64748b);
        size.setTextSize(12);
        size.setPadding(16, 0, 0, 0);
        row.addView(size);

        row.setOnClickListener(v -> {
            if (file.isDirectory()) {
                currentDir = file;
                refreshFileList();
            } else {
                showFileOptions(file);
            }
        });

        row.setOnLongClickListener(v -> {
            showFileOptions(file);
            return true;
        });

        fileListContainer.addView(row);
    }

    private String formatSize(long size) {
        if (size < 1024) return size + " B";
        if (size < 1024 * 1024) return String.format("%.1f KB", size / 1024.0);
        return String.format("%.1f MB", size / (1024.0 * 1024));
    }

    private void showFileOptions(File file) {
        String[] options = file.isDirectory()
            ? new String[]{"Open", "Rename", "Delete"}
            : new String[]{"Open", "Share", "Rename", "Delete"};

        new AlertDialog.Builder(this)
            .setTitle(file.getName())
            .setItems(options, (dialog, which) -> {
                switch (options[which]) {
                    case "Open":
                        if (file.isDirectory()) {
                            currentDir = file;
                            refreshFileList();
                        } else {
                            openFile(file);
                        }
                        break;
                    case "Share":
                        shareFile(file);
                        break;
                    case "Rename":
                        renameFile(file);
                        break;
                    case "Delete":
                        deleteFile(file);
                        break;
                }
            })
            .show();
    }

    private void openFile(File file) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        Uri uri = Uri.fromFile(file);
        String mime = getMimeType(file.getName());
        intent.setDataAndType(uri, mime);
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Cannot open file: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void shareFile(File file) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType(getMimeType(file.getName()));
        intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
        startActivity(Intent.createChooser(intent, "Share file"));
    }

    private void renameFile(File file) {
        EditText input = new EditText(this);
        input.setText(file.getName());

        new AlertDialog.Builder(this)
            .setTitle("Rename")
            .setView(input)
            .setPositiveButton("OK", (dialog, which) -> {
                String newName = input.getText().toString().trim();
                if (!newName.isEmpty()) {
                    File newFile = new File(file.getParentFile(), newName);
                    if (file.renameTo(newFile)) {
                        refreshFileList();
                    } else {
                        Toast.makeText(this, "Rename failed", Toast.LENGTH_SHORT).show();
                    }
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void deleteFile(File file) {
        new AlertDialog.Builder(this)
            .setTitle("Delete")
            .setMessage("Delete "" + file.getName() + ""?")
            .setPositiveButton("Delete", (dialog, which) -> {
                if (file.delete()) {
                    refreshFileList();
                } else {
                    Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void goUp() {
        File parent = currentDir.getParentFile();
        if (parent != null) {
            currentDir = parent;
            refreshFileList();
        }
    }

    private void createNewDirectory() {
        EditText input = new EditText(this);
        input.setHint("Directory name");

        new AlertDialog.Builder(this)
            .setTitle("New Directory")
            .setView(input)
            .setPositiveButton("Create", (dialog, which) -> {
                String name = input.getText().toString().trim();
                if (!name.isEmpty()) {
                    File newDir = new File(currentDir, name);
                    if (newDir.mkdirs()) {
                        refreshFileList();
                    } else {
                        Toast.makeText(this, "Create failed", Toast.LENGTH_SHORT).show();
                    }
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void createNewFile() {
        EditText input = new EditText(this);
        input.setHint("File name");

        new AlertDialog.Builder(this)
            .setTitle("New File")
            .setView(input)
            .setPositiveButton("Create", (dialog, which) -> {
                String name = input.getText().toString().trim();
                if (!name.isEmpty()) {
                    try {
                        File newFile = new File(currentDir, name);
                        if (newFile.createNewFile()) {
                            refreshFileList();
                        } else {
                            Toast.makeText(this, "File already exists", Toast.LENGTH_SHORT).show();
                        }
                    } catch (IOException e) {
                        Toast.makeText(this, "Create failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private String getMimeType(String filename) {
        if (filename.endsWith(".txt") || filename.endsWith(".md")) return "text/plain";
        if (filename.endsWith(".html") || filename.endsWith(".htm")) return "text/html";
        if (filename.endsWith(".js")) return "application/javascript";
        if (filename.endsWith(".css")) return "text/css";
        if (filename.endsWith(".json")) return "application/json";
        if (filename.endsWith(".xml")) return "text/xml";
        if (filename.endsWith(".png")) return "image/png";
        if (filename.endsWith(".jpg") || filename.endsWith(".jpeg")) return "image/jpeg";
        if (filename.endsWith(".gif")) return "image/gif";
        if (filename.endsWith(".pdf")) return "application/pdf";
        if (filename.endsWith(".apk")) return "application/vnd.android.package-archive";
        return "*/*";
    }
}
