# AGI Cognitive Fabric
## The Definitive FSM Kernel for Agentic General Intelligence

**Version:** 1.0.0-debug  
**License:** MIT  
**Runtime:** .NET 8.0  

---

## 🧠 Overview

The AGI Cognitive Fabric is a unified Agentic General Intelligence (AGI) platform built atop GitHub's automation and version-control substrate. It uses a **hierarchical Finite State Machine (FSM)** as its cognitive kernel to orchestrate autonomous agents across the entire software development lifecycle (SDLC), cloud infrastructure, and enterprise data estates.

### Three Cognitive Layers

| Layer | Agents | States |
|-------|--------|--------|
| **Development Core** | Architect, Engineer, Reviewer | `TRIAGE → DESIGN → IMPLEMENT → REVIEW → MERGE` |
| **Executive Function** | Infrastructure Healer | `ANOMALY_DETECTION → ISOLATION → ROOT_CAUSE → REMEDIATION → VERIFICATION` |
| **Analytical Cortex** | Data Synthesist | `INTENT_PARSING → SYNTAX_GENERATION → VALIDATION → INSIGHT_SYNTHESIS` |

---

## 🚀 Quick Start

```bash
# Clone and enter repository
git clone <repo-url>
cd agi-cognitive-fabric

# Run interactive quickstart
./scripts/quickstart.sh

# Or build everything
./scripts/build.sh --clean --sign --target all
```

---

## 📦 Release Artifacts

This release (`v1.0.0-debug`) includes the following signed artifacts:

| Artifact | Target | Description |
|----------|--------|-------------|
| `agi-fsm-debug-signed.tar.gz` | All | Debug-signed .NET assemblies with manifest |
| `agi-fsm-alpine-debug.tar.gz` | Alpine Linux | Docker image archive |
| `agi-fsm-systemd-debug.tar.gz` | Linux | Systemd service unit + install script |
| `agi-fsm-containerd-debug.tar.gz` | Containerd | OCI runtime spec + deploy script |
| `agi-fsm-virtualbox-debug.tar.gz` | VirtualBox | Vagrantfile + Alpine provisioning |
| `agi-fsm-overlay-debug.tar.gz` | Overlay FS | Ephemeral layered state deployment |
| `agi-fsm-network-debug.tar.gz` | Network NS | Isolated network namespace setup |
| `agi-fsm-devcontainer-debug.tar.gz` | VS Code | DevContainer configuration |

### Verify Debug Signature

```bash
# Extract public key and verify any DLL
tar -xzf agi-fsm-debug-signed.tar.gz debug-public-key.pem
./scripts/verify-signature.sh AGI.FSM.Core.dll AGI.FSM.Core.dll.sig debug-public-key.pem
```

---

## 🏗️ Architecture

### FSM Primitives

```
┌─────────────────────────────────────────────────────────────┐
│                    FINITE STATE MACHINE                       │
├─────────────────────────────────────────────────────────────┤
│  StateBase (Abstract)                                        │
│  ├── Begin()      → Auth, secrets, context setup            │
│  ├── Load()       → Heavy setup (clone repo, download TF)   │
│  ├── Update()     → Reasoning loop (LLM invocation)         │
│  └── End()        → Commit changes, cleanup, persist state  │
├─────────────────────────────────────────────────────────────┤
│  Event Bus                                                   │
│  ├── OnStateBegan  → Dashboard update, metrics              │
│  ├── OnStateChange → Meta-orchestrator MoveTo() trigger     │
│  └── OnStateEnded  → Slack/PR notifications                 │
├─────────────────────────────────────────────────────────────┤
│  StateInfo (Immutable Context Carrier)                       │
│  ├── GitHub Issue ID, commit hashes, ARNs                  │
│  ├── Conversation history, execution traces                  │
│  ├── Retry counters, diagnostic logs                        │
│  └── JSON-serializable for GitHub Actions injection         │
└─────────────────────────────────────────────────────────────┘
```

### Hierarchical Orchestration

```
Meta-Orchestrator FSM
├── TRIAGE → DESIGN → IMPLEMENT → REVIEW → MERGE
│   └── Subordinate FSMs:
│       ├── ArchitectAgent (DESIGN)
│       ├── EngineerAgent (IMPLEMENT)
│       └── ReviewerAgent (REVIEW)
├── Error path: IMPLEMENT → RECOVERY → RETRY
└── Manual override: MoveTo(HALT) via Issue comment
```

---

## 🐳 Deployment Targets

### 1. Alpine Linux Container

```bash
cd deploy/alpine
docker-compose up --build
```

- **Base image:** `mcr.microsoft.com/dotnet/aspnet:8.0-alpine`
- **Size:** ~120MB runtime
- **Includes:** `git`, `gh`, `kubectl`, `jq`
- **State volume:** `fsm-state` (persistent)

### 2. DevContainer (VS Code)

Open in VS Code with the Remote-Containers extension. Pre-configured with:
- .NET 8 SDK
- GitHub CLI
- kubectl + Helm
- Docker-in-Docker
- C# extensions + Copilot

### 3. Systemd Service

```bash
sudo ./deploy/systemd/install.sh
sudo systemctl start agi-fsm
sudo journalctl -u agi-fsm -f
```

**Security hardening:**
- `NoNewPrivileges=true`
- `ProtectSystem=strict`
- `MemoryDenyWriteExecute=true`
- Resource limits: 4GB RAM, 200% CPU

### 4. Containerd / runc

```bash
cd deploy/containerd
./deploy.sh
```

Uses OCI runtime spec with:
- PID, Network, IPC, UTS, Mount namespaces
- Memory limit: 2GB
- CPU shares: 1024
- Seccomp default profile

### 5. VirtualBox (Vagrant)

```bash
cd deploy/virtualbox
vagrant up
vagrant ssh
```

Alpine 3.19 VM with OpenRC init system.

### 6. Overlay Filesystem

```bash
sudo ./deploy/overlay/run-overlay.sh
```

Creates ephemeral execution environment:
- Lowerdir: Read-only application base
- Upperdir: Writable state layer (auto-committed to Git on exit)
- Workdir: OverlayFS working directory

### 7. Network Namespace Isolation

```bash
sudo ./deploy/network/setup-netns.sh
```

Creates isolated network stack:
- Bridge: `agi-br0` (10.200.1.1/24)
- FSM container: `10.200.1.2/24`
- NAT masquerading for external access
- Complete network segregation from host

---

## 🔐 Debug Signing

All release artifacts are signed with a debug RSA-2048 key for integrity verification.

**Key locations:**
- Private: `.keys/debug-signing-key.pem` (DO NOT COMMIT)
- Public: `debug-public-key.pem` (included in release)

**Signature format:**
- Algorithm: RSA-SHA256
- File: `{assembly}.dll.sig`
- Manifest: `MANIFEST.json`

---

## ⚙️ Configuration

### Workflow Definitions

Edit `config/workflows.yaml` to customize agent behavior:

```yaml
workflows:
  bug:
    label: "bug"
    transition_graph:
      - state: TRIAGE
        next: [DIAGNOSE]
        agent: triage
        timeout: 5m
```

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `FSM_STATE_SECRET` | HMAC key for state serialization | `AGI-FSM-DEBUG-KEY` |
| `GITHUB_TOKEN` | GitHub API authentication | *(required)* |
| `LLM_API_KEY` | LLM provider API key | *(required)* |
| `DOTNET_ENVIRONMENT` | Runtime environment | `Development` |
| `FSM_MAX_RUNTIME_MINUTES` | Watchdog timeout | `330` |

---

## 📊 Observability

### OpenTelemetry Integration

All state transitions emit structured telemetry:

```bash
# Start collector
docker-compose -f deploy/alpine/docker-compose.yml up otel-collector

# View traces
 curl http://localhost:4318/v1/traces
```

### Prometheus Metrics

- `agi_fsm_state_transitions_total` - Counter of state transitions
- `agi_fsm_state_duration_seconds` - Histogram of state durations
- `agi_fsm_agent_retries_total` - Counter of retry attempts
- `agi_fsm_active_states` - Gauge of currently active states

---

## 🧪 Testing

```bash
# Run all tests
dotnet test --configuration Debug

# Run specific agent tests
dotnet test --filter "FullyQualifiedName~ArchitectAgent"

# Run with coverage
dotnet test --collect:"XPlat Code Coverage"
```

---

## 🛡️ Security Considerations

1. **Secrets Management:** All secrets loaded from environment variables or files (never committed)
2. **State Integrity:** All serialized states are HMAC-SHA256 signed
3. **Capability Isolation:** EngineerAgent and InfrastructureAgent run in separate secret scopes
4. **Network Segmentation:** Optional network namespace isolation for untrusted agents
5. **Resource Limits:** CPU/memory constraints enforced at container/systemd level

---

## 🤝 Contributing

1. Open an Issue with label `agent-request`
2. The FSM orchestrator will auto-triage and assign to appropriate agent
3. Agent creates PR for human review
4. Merge triggers next state transition

---

## 📄 License

MIT License - See LICENSE file for details.

---

**Built with:** .NET 8.0 | Alpine Linux | GitHub Actions | OpenTelemetry | Finite State Machines

*"Moving from prompt to production without a single human imperative dictating the intermediate steps."*
