#!/bin/bash
# =============================================================================
# AGI Cognitive Fabric - Debug Signature Verification
# =============================================================================

set -e

if [ $# -lt 2 ]; then
    echo "Usage: $0 <dll-file> <signature-file> [public-key-file]"
    echo "Example: $0 AGI.FSM.Core.dll AGI.FSM.Core.dll.sig debug-public-key.pem"
    exit 1
fi

DLL_FILE="$1"
SIG_FILE="$2"
PUB_KEY="${3:-debug-public-key.pem}"

if [ ! -f "$DLL_FILE" ]; then
    echo "Error: DLL file not found: $DLL_FILE"
    exit 1
fi

if [ ! -f "$SIG_FILE" ]; then
    echo "Error: Signature file not found: $SIG_FILE"
    exit 1
fi

if [ ! -f "$PUB_KEY" ]; then
    echo "Error: Public key not found: $PUB_KEY"
    exit 1
fi

echo "[VERIFY] Verifying debug signature..."
echo "  DLL:    $DLL_FILE"
echo "  Sig:    $SIG_FILE"
echo "  PubKey: $PUB_KEY"

if openssl dgst -sha256 -verify "$PUB_KEY" -signature "$SIG_FILE" "$DLL_FILE"; then
    echo "[VERIFY] ✓ Signature VALID"
    exit 0
else
    echo "[VERIFY] ✗ Signature INVALID"
    exit 1
fi
