#!/bin/bash
# =============================================================================
# AGI Cognitive Fabric - Master Build Script
# Builds debug-signed release bundle for all target environments
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
BUILD_DIR="${PROJECT_ROOT}/build"
OUTPUT_DIR="${PROJECT_ROOT}/dist"
VERSION="1.0.0-debug"
BUILD_TIMESTAMP=$(date -u +"%Y%m%d%H%M%S")

echo "╔════════════════════════════════════════════════════════════╗"
echo "║   AGI COGNITIVE FABRIC - DEBUG BUILD SYSTEM              ║"
echo "║   Version: ${VERSION}                                      ║"
echo "╚════════════════════════════════════════════════════════════╝"

# Parse arguments
CLEAN=false
SIGN=false
TARGET="all"

while [[ $# -gt 0 ]]; do
    case $1 in
        --clean) CLEAN=true; shift ;;
        --sign) SIGN=true; shift ;;
        --target) TARGET="$2"; shift 2 ;;
        --help)
            echo "Usage: $0 [OPTIONS]"
            echo "Options:"
            echo "  --clean      Clean before build"
            echo "  --sign       Generate debug signatures"
            echo "  --target     Build target: all|alpine|systemd|containerd|vbox|overlay|network"
            echo "  --help       Show this help"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

# Clean if requested
if [ "$CLEAN" = true ]; then
    echo "[BUILD] Cleaning..."
    rm -rf "${BUILD_DIR}" "${OUTPUT_DIR}"
fi

mkdir -p "${BUILD_DIR}" "${OUTPUT_DIR}"

# =============================================================================
# PHASE 1: Restore & Build .NET Solution
# =============================================================================
echo "[BUILD] Restoring NuGet packages..."
cd "${PROJECT_ROOT}"
dotnet restore AGI-Cognitive-Fabric.sln

echo "[BUILD] Building Debug configuration..."
dotnet build AGI-Cognitive-Fabric.sln     --configuration Debug     --no-restore     --verbosity minimal

# =============================================================================
# PHASE 2: Generate Debug Signing Key (if not exists)
# =============================================================================
KEY_DIR="${PROJECT_ROOT}/.keys"
mkdir -p "${KEY_DIR}"

if [ ! -f "${KEY_DIR}/debug-signing-key.pem" ]; then
    echo "[BUILD] Generating debug RSA key pair..."
    openssl genrsa -out "${KEY_DIR}/debug-signing-key.pem" 2048
    openssl rsa -in "${KEY_DIR}/debug-signing-key.pem" -pubout -out "${KEY_DIR}/debug-public-key.pem"
    chmod 600 "${KEY_DIR}/debug-signing-key.pem"
fi

# =============================================================================
# PHASE 3: Sign Assemblies (Debug Signature)
# =============================================================================
if [ "$SIGN" = true ]; then
    echo "[BUILD] Signing assemblies with debug key..."

    SIGN_DIR="${BUILD_DIR}/signed"
    mkdir -p "${SIGN_DIR}"

    # Copy all DLLs and PDBs
    find "${PROJECT_ROOT}/src" -path "*/bin/Debug/net8.0/*.dll" -exec cp {} "${SIGN_DIR}/" \;
    find "${PROJECT_ROOT}/src" -path "*/bin/Debug/net8.0/*.pdb" -exec cp {} "${SIGN_DIR}/" \;

    # Sign each DLL
    for dll in "${SIGN_DIR}"/*.dll; do
        [ -e "$dll" ] || continue
        base=$(basename "$dll")
        echo "  Signing: ${base}"
        openssl dgst -sha256             -sign "${KEY_DIR}/debug-signing-key.pem"             -out "${SIGN_DIR}/${base}.sig"             "$dll"
    done

    # Generate manifest
    cat > "${SIGN_DIR}/MANIFEST.json" <<EOF
{
  "version": "${VERSION}",
  "buildTimestamp": "${BUILD_TIMESTAMP}",
  "signatureAlgorithm": "RSA-SHA256",
  "publicKeyPath": "debug-public-key.pem",
  "artifacts": [
$(for f in "${SIGN_DIR}"/*.dll; do
    [ -e "$f" ] || continue
    echo "    {"file": "$(basename "$f")", "sig": "$(basename "$f").sig"},"
done | sed '$ s/,$//')
  ]
}
EOF

    # Create signed bundle
    tar -czf "${OUTPUT_DIR}/agi-fsm-debug-signed-${BUILD_TIMESTAMP}.tar.gz"         -C "${SIGN_DIR}" .         -C "${KEY_DIR}" debug-public-key.pem

    # Generate checksums
    cd "${OUTPUT_DIR}"
    sha256sum "agi-fsm-debug-signed-${BUILD_TIMESTAMP}.tar.gz" > checksums-sha256.txt
    md5sum "agi-fsm-debug-signed-${BUILD_TIMESTAMP}.tar.gz" > checksums-md5.txt

    echo "[BUILD] Signed bundle created: ${OUTPUT_DIR}/agi-fsm-debug-signed-${BUILD_TIMESTAMP}.tar.gz"
fi

# =============================================================================
# PHASE 4: Build Container Images
# =============================================================================
build_alpine() {
    echo "[BUILD] Building Alpine container..."
    docker build         -f "${PROJECT_ROOT}/deploy/alpine/Dockerfile"         -t "agi-fsm:alpine-debug"         -t "agi-fsm:alpine-${BUILD_TIMESTAMP}"         "${PROJECT_ROOT}"

    docker save "agi-fsm:alpine-debug" | gzip > "${OUTPUT_DIR}/agi-fsm-alpine-debug.tar.gz"
    echo "[BUILD] Alpine image saved: ${OUTPUT_DIR}/agi-fsm-alpine-debug.tar.gz"
}

# =============================================================================
# PHASE 5: Package Environment Configs
# =============================================================================
package_envs() {
    echo "[BUILD] Packaging environment configurations..."

    # Systemd package
    tar -czf "${OUTPUT_DIR}/agi-fsm-systemd-debug.tar.gz"         -C "${PROJECT_ROOT}/deploy/systemd" .

    # Containerd package
    tar -czf "${OUTPUT_DIR}/agi-fsm-containerd-debug.tar.gz"         -C "${PROJECT_ROOT}/deploy/containerd" .

    # VirtualBox package
    tar -czf "${OUTPUT_DIR}/agi-fsm-virtualbox-debug.tar.gz"         -C "${PROJECT_ROOT}/deploy/virtualbox" .

    # Overlay package
    tar -czf "${OUTPUT_DIR}/agi-fsm-overlay-debug.tar.gz"         -C "${PROJECT_ROOT}/deploy/overlay" .

    # Network package
    tar -czf "${OUTPUT_DIR}/agi-fsm-network-debug.tar.gz"         -C "${PROJECT_ROOT}/deploy/network" .

    # DevContainer package
    tar -czf "${OUTPUT_DIR}/agi-fsm-devcontainer-debug.tar.gz"         -C "${PROJECT_ROOT}" .devcontainer
}

# =============================================================================
# PHASE 6: Execute Target Builds
# =============================================================================
case "$TARGET" in
    all)
        build_alpine
        package_envs
        ;;
    alpine)
        build_alpine
        ;;
    systemd|containerd|vbox|overlay|network)
        package_envs
        ;;
    *)
        echo "Unknown target: $TARGET"
        exit 1
        ;;
esac

# =============================================================================
# PHASE 7: Generate Release Metadata
# =============================================================================
cat > "${OUTPUT_DIR}/RELEASE.json" <<EOF
{
  "name": "AGI Cognitive Fabric",
  "version": "${VERSION}",
  "buildTimestamp": "${BUILD_TIMESTAMP}",
  "gitCommit": "$(git rev-parse HEAD 2>/dev/null || echo 'unknown')",
  "gitBranch": "$(git branch --show-current 2>/dev/null || echo 'unknown')",
  "targets": {
    "alpine": "agi-fsm-alpine-debug.tar.gz",
    "systemd": "agi-fsm-systemd-debug.tar.gz",
    "containerd": "agi-fsm-containerd-debug.tar.gz",
    "virtualbox": "agi-fsm-virtualbox-debug.tar.gz",
    "overlay": "agi-fsm-overlay-debug.tar.gz",
    "network": "agi-fsm-network-debug.tar.gz",
    "devcontainer": "agi-fsm-devcontainer-debug.tar.gz"
  },
  "signed": ${SIGN},
  "checksums": "checksums-sha256.txt"
}
EOF

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║   BUILD COMPLETE                                          ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo "Output directory: ${OUTPUT_DIR}"
ls -lh "${OUTPUT_DIR}"
