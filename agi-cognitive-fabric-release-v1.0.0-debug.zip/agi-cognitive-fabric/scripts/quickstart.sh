#!/bin/bash
# =============================================================================
# AGI Cognitive Fabric - Quick Start
# =============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

echo "AGI Cognitive Fabric - Quick Start"
echo "==================================="
echo ""

# Check prerequisites
check_prereq() {
    if command -v "$1" &> /dev/null; then
        echo "✓ $1: $(command -v $1)"
        return 0
    else
        echo "✗ $1: NOT FOUND"
        return 1
    fi
}

echo "Checking prerequisites..."
check_prereq dotnet
check_prereq docker
check_prereq git
check_prereq gh || true

echo ""
echo "Choose deployment target:"
echo "  1) Native (.NET runtime)"
echo "  2) Alpine Docker container"
echo "  3) DevContainer (VS Code)"
echo "  4) Systemd service"
echo "  5) VirtualBox (Vagrant)"
echo "  6) Build all release artifacts"
read -p "Selection [1-6]: " choice

case $choice in
    1)
        echo "[START] Running native debug build..."
        cd "${PROJECT_ROOT}"
        dotnet restore
        dotnet build --configuration Debug
        dotnet run --project src/AGI.FSM.Host/AGI.FSM.Host.csproj -- "QUICKSTART-001"
        ;;
    2)
        echo "[START] Starting Alpine container..."
        cd "${PROJECT_ROOT}/deploy/alpine"
        docker-compose up --build
        ;;
    3)
        echo "[START] Open this directory in VS Code with Remote-Containers extension"
        echo "  code ${PROJECT_ROOT}"
        ;;
    4)
        echo "[START] Installing systemd service..."
        sudo "${PROJECT_ROOT}/deploy/systemd/install.sh"
        sudo systemctl start agi-fsm
        ;;
    5)
        echo "[START] Starting VirtualBox VM..."
        cd "${PROJECT_ROOT}/deploy/virtualbox"
        vagrant up
        vagrant ssh
        ;;
    6)
        echo "[START] Building all release artifacts..."
        "${PROJECT_ROOT}/scripts/build.sh" --clean --sign --target all
        ;;
    *)
        echo "Invalid selection"
        exit 1
        ;;
esac
