using System;
using System.IO;
using System.Threading;
using AGI.FSM.Core;
using AGI.FSM.Agents;
using Microsoft.Extensions.Logging;

namespace AGI.FSM.Host
{
    class Program
    {
        static void Main(string[] args)
        {
            var loggerFactory = LoggerFactory.Create(builder => builder.AddConsole());
            var logger = loggerFactory.CreateLogger<Program>();

            logger.LogInformation("╔════════════════════════════════════════════════════════════╗");
            logger.LogInformation("║   AGI COGNITIVE FABRIC - FSM KERNEL v1.0.0-debug         ║");
            logger.LogInformation("║   Finite State Machine Orchestration Engine                ║");
            logger.LogInformation("╚════════════════════════════════════════════════════════════╝");

            var fsm = FiniteStateMachine.Instance;
            fsm.Initialize();

            // Wire up event bus
            fsm.OnStateBegan += e => logger.LogInformation("[EVENT] State began: {State}", e.State);
            fsm.OnStateChange += e => logger.LogInformation("[EVENT] Transition: {From} -> {To} via {Event}", e.FromState, e.ToState, e.TriggerEvent);
            fsm.OnStateEnded += e => logger.LogInformation("[EVENT] State ended: {State} after {Duration}s", e.State, e.Duration.TotalSeconds);

            // Register states
            fsm.AddState(new TriageState(fsm, logger));
            fsm.AddState(new ArchitectAgent(fsm, new MockInferenceEngine(), new MockGitHubClient(), logger));
            fsm.AddState(new EngineerAgent(fsm, new MockInferenceEngine(), new MockGitHubClient(), new MockCIClient(), logger));
            fsm.AddState(new ReviewState(fsm, logger));
            fsm.AddState(new RecoveryState(fsm, logger));
            fsm.AddState(new HaltState(fsm, logger));

            // Start from TRIAGE
            var initialInfo = new DefaultStateInfo
            {
                GitHubIssueId = args.Length > 0 ? args[0] : "DEMO-001",
                Payload = { ["issue_body"] = "Implement FSM kernel for AGI platform" }
            };

            fsm.MoveTo(StateType.TRIAGE, new FiniteStateChangeEventArgs(StateType.IDLE, StateType.TRIAGE, initialInfo)
            {
                TriggerEvent = "INIT"
            });

            // Main reasoning loop with watchdog
            var watchDog = new WatchdogTimer(TimeSpan.FromHours(5.5)); // GitHub Actions 6h limit buffer
            var deltaTime = 1.0f;

            while (fsm.CurrentState != StateType.HALT && fsm.CurrentState != StateType.IDLE)
            {
                if (watchDog.IsExpired)
                {
                    logger.LogWarning("[WATCHDOG] Approaching GitHub Actions time limit. Graceful shutdown...");
                    fsm.Shutdown();
                    break;
                }

                fsm.Update(deltaTime);
                Thread.Sleep(1000); // 1s tick
            }

            logger.LogInformation("[HOST] FSM execution complete. Final state: {State}", fsm.CurrentState);
            fsm.Dispose();
        }
    }

    // Mock implementations for standalone execution
    class MockInferenceEngine : IInferenceEngine
    {
        public Task<InferenceResult> ReasonAsync(string prompt, StateInfo context, InferenceOptions options = null)
        {
            return Task.FromResult(new InferenceResult
            {
                Success = true,
                Output = $"[MOCK] Reasoned about: {prompt.Substring(0, Math.Min(50, prompt.Length))}...",
                TokensUsed = 150
            });
        }

        public Task<bool> ValidateAsync(string output, StateInfo context) => Task.FromResult(true);
    }

    class MockGitHubClient : IGitHubClient
    {
        public string GetRepositoryContext(string issueId) => "mock-repo-context";
        public void CreateBranch(string branchName) { }
        public void CommitChanges(string branchName, string content) { }
        public PullRequest CreatePullRequest(string branchName, string title) => new() { Number = 42 };
    }

    class MockCIClient : ICIClient
    {
        public CIStatus PollStatus(int? prNumber) => new() { IsSuccess = true };
    }

    class TriageState : StateBase
    {
        public TriageState(FiniteStateMachine fsm, ILogger logger) : base(fsm, StateType.TRIAGE, logger) { }
        protected override void AuthenticateServices(StateInfo info) { }
        protected override void ExecuteReasoningLoop(float deltaTime)
        {
            Logger?.LogInformation("[TRIAGE] Classifying issue #{Issue}...", GetCurrentStateInfo()?.GitHubIssueId);
            Fsm.MoveTo(StateType.DESIGN, new FiniteStateChangeEventArgs(StateType.TRIAGE, StateType.DESIGN, GetCurrentStateInfo())
            {
                TriggerEvent = "TRIAGE_COMPLETE"
            });
        }
        protected override void CleanupResources() { }
    }

    class ReviewState : StateBase
    {
        public ReviewState(FiniteStateMachine fsm, ILogger logger) : base(fsm, StateType.REVIEW, logger) { }
        protected override void AuthenticateServices(StateInfo info) { }
        protected override void ExecuteReasoningLoop(float deltaTime)
        {
            Logger?.LogInformation("[REVIEW] Reviewing implementation...");
            Fsm.MoveTo(StateType.MERGE, new FiniteStateChangeEventArgs(StateType.REVIEW, StateType.MERGE, GetCurrentStateInfo())
            {
                TriggerEvent = "REVIEW_PASSED"
            });
        }
        protected override void CleanupResources() { }
    }

    class RecoveryState : StateBase
    {
        public RecoveryState(FiniteStateMachine fsm, ILogger logger) : base(fsm, StateType.RECOVERY, logger) { }
        protected override void AuthenticateServices(StateInfo info) { }
        protected override void ExecuteReasoningLoop(float deltaTime)
        {
            Logger?.LogInformation("[RECOVERY] Attempting recovery...");
            Fsm.MoveTo(StateType.HALT, new FiniteStateChangeEventArgs(StateType.RECOVERY, StateType.HALT, GetCurrentStateInfo())
            {
                TriggerEvent = "RECOVERY_COMPLETE"
            });
        }
        protected override void CleanupResources() { }
    }

    class HaltState : StateBase
    {
        public HaltState(FiniteStateMachine fsm, ILogger logger) : base(fsm, StateType.HALT, logger) { }
        protected override void AuthenticateServices(StateInfo info) { }
        protected override void ExecuteReasoningLoop(float deltaTime) { }
        protected override void CleanupResources() { }
    }

    class WatchdogTimer
    {
        private readonly DateTime _expiry;
        public bool IsExpired => DateTime.UtcNow >= _expiry;
        public WatchdogTimer(TimeSpan duration) => _expiry = DateTime.UtcNow.Add(duration);
    }
}
