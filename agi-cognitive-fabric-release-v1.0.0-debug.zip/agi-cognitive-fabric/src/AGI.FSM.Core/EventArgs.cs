using System;

namespace AGI.FSM.Core
{
    public class FiniteStateBeganEventArgs : EventArgs
    {
        public StateType State { get; }
        public StateInfo Info { get; }
        public DateTime Timestamp { get; } = DateTime.UtcNow;

        public FiniteStateBeganEventArgs(StateType state, StateInfo info)
        {
            State = state;
            Info = info;
        }
    }

    public class FiniteStateChangeEventArgs : EventArgs
    {
        public StateType FromState { get; }
        public StateType ToState { get; }
        public StateInfo Info { get; }
        public DateTime Timestamp { get; } = DateTime.UtcNow;
        public string TriggerEvent { get; set; }

        public FiniteStateChangeEventArgs(StateType fromState, StateType toState, StateInfo info)
        {
            FromState = fromState;
            ToState = toState;
            Info = info;
        }
    }

    public class FiniteStateEndedEventArgs : EventArgs
    {
        public StateType State { get; }
        public StateInfo Info { get; }
        public DateTime Timestamp { get; } = DateTime.UtcNow;
        public TimeSpan Duration { get; set; }

        public FiniteStateEndedEventArgs(StateType state, StateInfo info)
        {
            State = state;
            Info = info;
        }
    }
}
