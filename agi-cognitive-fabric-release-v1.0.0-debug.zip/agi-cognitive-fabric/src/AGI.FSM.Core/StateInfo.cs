using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace AGI.FSM.Core
{
    [Serializable]
    public abstract class StateInfo
    {
        [JsonProperty("timestamp")]
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;

        [JsonProperty("githubIssueId")]
        public string GitHubIssueId { get; set; }

        [JsonProperty("commitHash")]
        public string CommitHash { get; set; }

        [JsonProperty("diagnosticLogs")]
        public List<string> DiagnosticLogs { get; set; } = new List<string>();

        [JsonProperty("cloudResourceArns")]
        public List<string> CloudResourceArns { get; set; } = new List<string>();

        [JsonProperty("queryExecutionPlan")]
        public string QueryExecutionPlan { get; set; }

        [JsonProperty("conversationHistory")]
        public List<ConversationTurn> ConversationHistory { get; set; } = new List<ConversationTurn>();

        [JsonProperty("executionTraces")]
        public List<ExecutionTrace> ExecutionTraces { get; set; } = new List<ExecutionTrace>();

        [JsonProperty("retryCount")]
        public int RetryCount { get; set; } = 0;

        [JsonProperty("maxRetries")]
        public int MaxRetries { get; set; } = 3;

        [JsonProperty("payload")]
        public JObject Payload { get; set; } = new JObject();

        [JsonProperty("cancellationRequested")]
        public bool CancellationRequested { get; set; } = false;

        [JsonProperty("previousState")]
        public StateType PreviousState { get; set; } = StateType.IDLE;

        [JsonProperty("transitionHistory")]
        public List<TransitionRecord> TransitionHistory { get; set; } = new List<TransitionRecord>();

        public abstract override string ToString();

        public string ToJson() => JsonConvert.SerializeObject(this, Formatting.Indented);

        public static T FromJson<T>(string json) where T : StateInfo => 
            JsonConvert.DeserializeObject<T>(json);
    }

    [Serializable]
    public class ConversationTurn
    {
        [JsonProperty("role")]
        public string Role { get; set; }
        [JsonProperty("content")]
        public string Content { get; set; }
        [JsonProperty("timestamp")]
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    }

    [Serializable]
    public class ExecutionTrace
    {
        [JsonProperty("tool")]
        public string Tool { get; set; }
        [JsonProperty("input")]
        public string Input { get; set; }
        [JsonProperty("output")]
        public string Output { get; set; }
        [JsonProperty("error")]
        public string Error { get; set; }
        [JsonProperty("durationMs")]
        public long DurationMs { get; set; }
    }

    [Serializable]
    public class TransitionRecord
    {
        [JsonProperty("fromState")]
        public StateType FromState { get; set; }
        [JsonProperty("toState")]
        public StateType ToState { get; set; }
        [JsonProperty("timestamp")]
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        [JsonProperty("eventType")]
        public string EventType { get; set; }
    }
}
