using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace AGI.FSM.Core
{
    public class StateSerializer
    {
        private readonly ILogger _logger;
        private readonly string _secretKey;

        public StateSerializer(ILogger logger = null, string secretKey = null)
        {
            _logger = logger;
            _secretKey = secretKey ?? Environment.GetEnvironmentVariable("FSM_STATE_SECRET") ?? "AGI-FSM-DEBUG-KEY";
        }

        public void SerializeState(FiniteStateMachine fsm, string path)
        {
            try
            {
                var stateData = new SerializedFsmState
                {
                    CurrentState = fsm.CurrentState,
                    PreviousState = fsm.PreviousState,
                    StateInfo = fsm.CurrentStateInfo,
                    StartTime = fsm.StartTime,
                    Timestamp = DateTime.UtcNow
                };

                var json = JsonConvert.SerializeObject(stateData, Formatting.Indented);
                var signature = ComputeSignature(json);

                var envelope = new StateEnvelope
                {
                    Data = json,
                    Signature = signature,
                    Algorithm = "HMACSHA256"
                };

                var output = JsonConvert.SerializeObject(envelope, Formatting.Indented);

                Directory.CreateDirectory(Path.GetDirectoryName(path) ?? ".fsm");
                File.WriteAllText(path, output);

                _logger?.LogInformation("[Serializer] State persisted to {Path}", path);
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "[Serializer] Failed to persist state to {Path}", path);
                throw;
            }
        }

        public bool TryDeserializeState(string path, out SerializedFsmState state)
        {
            state = null;
            try
            {
                if (!File.Exists(path)) return false;

                var envelope = JsonConvert.DeserializeObject<StateEnvelope>(File.ReadAllText(path));
                if (!VerifySignature(envelope.Data, envelope.Signature))
                {
                    _logger?.LogError("[Serializer] State signature verification failed!");
                    return false;
                }

                state = JsonConvert.DeserializeObject<SerializedFsmState>(envelope.Data);
                return true;
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "[Serializer] Failed to deserialize state from {Path}", path);
                return false;
            }
        }

        private string ComputeSignature(string data)
        {
            using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(_secretKey));
            var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(data));
            return Convert.ToBase64String(hash);
        }

        private bool VerifySignature(string data, string signature)
        {
            var computed = ComputeSignature(data);
            return computed.Equals(signature);
        }
    }

    public class SerializedFsmState
    {
        [JsonProperty("currentState")]
        public StateType CurrentState { get; set; }
        [JsonProperty("previousState")]
        public StateType PreviousState { get; set; }
        [JsonProperty("stateInfo")]
        public StateInfo StateInfo { get; set; }
        [JsonProperty("startTime")]
        public DateTime StartTime { get; set; }
        [JsonProperty("timestamp")]
        public DateTime Timestamp { get; set; }
    }

    public class StateEnvelope
    {
        [JsonProperty("data")]
        public string Data { get; set; }
        [JsonProperty("signature")]
        public string Signature { get; set; }
        [JsonProperty("algorithm")]
        public string Algorithm { get; set; }
    }
}
