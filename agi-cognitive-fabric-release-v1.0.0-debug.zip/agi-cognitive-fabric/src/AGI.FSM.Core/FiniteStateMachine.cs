using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace AGI.FSM.Core
{
    public sealed class FiniteStateMachine : IDisposable
    {
        private static readonly Lazy<FiniteStateMachine> _instance = 
            new Lazy<FiniteStateMachine>(() => new FiniteStateMachine());
        public static FiniteStateMachine Instance => _instance.Value;

        private readonly ConcurrentDictionary<StateType, StateBase> _states = new();
        private readonly object _transitionLock = new();
        private readonly ILogger _logger;
        private readonly StateSerializer _serializer;

        public StateType CurrentState { get; private set; } = StateType.IDLE;
        public StateType PreviousState { get; private set; } = StateType.IDLE;
        public StateInfo CurrentStateInfo { get; private set; }
        public bool IsInitialized { get; private set; }
        public DateTime StartTime { get; private set; }

        // Event Bus
        public event Action<FiniteStateBeganEventArgs> OnStateBegan;
        public event Action<FiniteStateChangeEventArgs> OnStateChange;
        public event Action<FiniteStateEndedEventArgs> OnStateEnded;

        private FiniteStateMachine(ILogger logger = null)
        {
            _logger = logger;
            _serializer = new StateSerializer(logger);
        }

        public void Initialize(StateInfo initialStateInfo = null)
        {
            if (IsInitialized) return;

            StartTime = DateTime.UtcNow;
            CurrentStateInfo = initialStateInfo ?? new DefaultStateInfo();
            IsInitialized = true;

            _logger?.LogInformation("[FSM] Initialized. StartTime: {StartTime}", StartTime);
        }

        public void AddState(StateBase state)
        {
            if (!_states.TryAdd(state.StateKey, state))
            {
                throw new InvalidOperationException($"State {state.StateKey} already registered.");
            }
            _logger?.LogInformation("[FSM] Registered state: {State}", state.StateKey);
        }

        public void MoveTo(StateType targetState, FiniteStateChangeEventArgs eventArgs)
        {
            lock (_transitionLock)
            {
                var previousState = CurrentState;
                var previousStateInfo = CurrentStateInfo;

                try
                {
                    // Validate target state exists
                    if (!_states.ContainsKey(targetState))
                    {
                        throw new KeyNotFoundException($"State {targetState} not registered.");
                    }

                    // Atomic transition: End current state
                    if (_states.TryGetValue(CurrentState, out var currentStateObj) && CurrentState != StateType.IDLE)
                    {
                        var endArgs = new FiniteStateEndedEventArgs(CurrentState, CurrentStateInfo)
                        {
                            Duration = DateTime.UtcNow - StartTime
                        };

                        currentStateObj.End();
                        OnStateEnded?.Invoke(endArgs);

                        // Persist state before transition
                        _serializer.SerializeState(this, $".fsm/state_{DateTime.UtcNow:yyyyMMddHHmmss}.json");
                    }

                    // Update tracking
                    PreviousState = previousState;
                    CurrentState = targetState;
                    CurrentStateInfo = eventArgs.Info ?? previousStateInfo;

                    // Record transition
                    CurrentStateInfo.TransitionHistory.Add(new TransitionRecord
                    {
                        FromState = previousState,
                        ToState = targetState,
                        EventType = eventArgs.TriggerEvent ?? "MANUAL"
                    });

                    // Begin new state
                    var changeArgs = new FiniteStateChangeEventArgs(previousState, targetState, CurrentStateInfo)
                    {
                        TriggerEvent = eventArgs.TriggerEvent
                    };

                    OnStateChange?.Invoke(changeArgs);

                    var newState = _states[targetState];
                    newState.Begin(changeArgs, previousState);

                    var beganArgs = new FiniteStateBeganEventArgs(targetState, CurrentStateInfo);
                    OnStateBegan?.Invoke(beganArgs);

                    _logger?.LogInformation("[FSM] Transitioned: {From} -> {To}", previousState, targetState);
                }
                catch (Exception ex)
                {
                    _logger?.LogError(ex, "[FSM] Transition failed: {From} -> {To}. Reverting...", previousState, targetState);

                    // Atomic rollback
                    CurrentState = previousState;
                    CurrentStateInfo = previousStateInfo;

                    // Log failure
                    CurrentStateInfo.DiagnosticLogs.Add($"[TRANSITION_FAILURE] {ex.Message}");

                    throw;
                }
            }
        }

        public void Update(float deltaTime)
        {
            if (!IsInitialized) throw new InvalidOperationException("FSM not initialized.");
            if (_states.TryGetValue(CurrentState, out var state))
            {
                state.Update(deltaTime);
            }
        }

        public void Shutdown()
        {
            _logger?.LogInformation("[FSM] Shutting down...");

            if (_states.TryGetValue(CurrentState, out var state))
            {
                state.End();
            }

            // Final persistence
            _serializer.SerializeState(this, ".fsm/final_state.json");

            IsInitialized = false;
        }

        public void Dispose()
        {
            foreach (var state in _states.Values)
            {
                state.Dispose();
            }
            _states.Clear();
        }
    }

    public class DefaultStateInfo : StateInfo
    {
        public override string ToString() => $"[DefaultStateInfo] {Timestamp:O}";
    }
}
