namespace AGI.FSM.Core
{
    public enum StateType
    {
        // Meta-Orchestrator States
        TRIAGE = 0,
        DESIGN = 1,
        IMPLEMENT = 2,
        REVIEW = 3,
        MERGE = 4,
        RECOVERY = 5,
        HALT = 6,

        // Analytical Cortex States
        INTENT_PARSING = 100,
        SYNTAX_GENERATION = 101,
        VALIDATION = 102,
        SELF_HEAL = 103,
        INSIGHT_SYNTHESIS = 104,

        // Executive Function States
        ANOMALY_DETECTION = 200,
        ISOLATION = 201,
        ROOT_CAUSE = 202,
        REMEDIATION = 203,
        VERIFICATION = 204,
        ESCALATION = 205,

        // Generic
        PLANNING = 300,
        EXECUTING = 301,
        VALIDATING = 302,
        IDLE = 303,
        ERROR = 304
    }
}
