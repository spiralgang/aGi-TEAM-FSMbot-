using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace AGI.FSM.Core
{
    public abstract class StateBase : IDisposable
    {
        protected readonly FiniteStateMachine Fsm;
        protected readonly ILogger Logger;
        public StateType StateKey { get; }

        public virtual TimeSpan BeginTimeout => TimeSpan.FromMinutes(2);
        public virtual TimeSpan UpdateTimeout => TimeSpan.FromMinutes(10);
        public virtual TimeSpan EndTimeout => TimeSpan.FromMinutes(1);

        private DateTime _stateStartTime;
        private CancellationTokenSource _cts;
        private bool _isDisposed;

        protected StateBase(FiniteStateMachine fsm, StateType stateKey, ILogger logger = null)
        {
            Fsm = fsm ?? throw new ArgumentNullException(nameof(fsm));
            StateKey = stateKey;
            Logger = logger;
            _cts = new CancellationTokenSource();
        }

        public virtual void Begin(FiniteStateChangeEventArgs eventArgs, StateType previousStateKey)
        {
            _stateStartTime = DateTime.UtcNow;
            _cts = new CancellationTokenSource();

            Logger?.LogInformation("[FSM] State {State} began. Previous: {Previous}. Issue: {Issue}", 
                StateKey, previousStateKey, eventArgs.Info?.GitHubIssueId ?? "N/A");

            // Authenticate with external services
            AuthenticateServices(eventArgs.Info);
        }

        public virtual void Load()
        {
            Logger?.LogInformation("[FSM] State {State} loading heavy resources...", StateKey);
        }

        public virtual void Update(float deltaTime)
        {
            if (_cts.Token.IsCancellationRequested)
            {
                Logger?.LogWarning("[FSM] State {State} received halt signal. Initiating graceful termination...", StateKey);
                Fsm.MoveTo(StateType.HALT, new FiniteStateChangeEventArgs(StateKey, StateType.HALT, GetCurrentStateInfo()));
                return;
            }

            // Core reasoning loop - to be overridden by agents
            ExecuteReasoningLoop(deltaTime);
        }

        public virtual void End()
        {
            var duration = DateTime.UtcNow - _stateStartTime;
            Logger?.LogInformation("[FSM] State {State} ended. Duration: {Duration}s", StateKey, duration.TotalSeconds);

            // Cleanup ephemeral resources
            CleanupResources();

            // Dispose cancellation token
            _cts?.Cancel();
            _cts?.Dispose();
        }

        protected abstract void ExecuteReasoningLoop(float deltaTime);
        protected abstract void AuthenticateServices(StateInfo info);
        protected abstract void CleanupResources();

        protected StateInfo GetCurrentStateInfo() => Fsm?.CurrentStateInfo;

        public void RequestCancellation()
        {
            _cts?.Cancel();
        }

        public void Dispose()
        {
            if (_isDisposed) return;
            _cts?.Dispose();
            _isDisposed = true;
            GC.SuppressFinalize(this);
        }
    }
}
