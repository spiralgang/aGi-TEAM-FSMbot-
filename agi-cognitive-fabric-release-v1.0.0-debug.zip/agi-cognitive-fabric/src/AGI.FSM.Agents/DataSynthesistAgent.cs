using System;
using System.Linq;
using AGI.FSM.Core;
using Microsoft.Extensions.Logging;

namespace AGI.FSM.Agents
{
    public class DataSynthesistAgent : StateBase
    {
        private readonly IInferenceEngine _inferenceEngine;
        private readonly IDatabaseClient _dbClient;
        private readonly ISandboxExecutor _sandbox;

        public DataSynthesistAgent(FiniteStateMachine fsm, IInferenceEngine engine, IDatabaseClient db, ISandboxExecutor sandbox, ILogger logger)
            : base(fsm, StateType.INTENT_PARSING, logger)
        {
            _inferenceEngine = engine;
            _dbClient = db;
            _sandbox = sandbox;
        }

        protected override void AuthenticateServices(StateInfo info)
        {
            Logger?.LogInformation("[Data] Authenticating with data warehouse...");
        }

        protected override void ExecuteReasoningLoop(float deltaTime)
        {
            var info = GetCurrentStateInfo();
            if (info == null) return;

            switch (Fsm.CurrentState)
            {
                case StateType.INTENT_PARSING:
                    ParseIntent(info);
                    break;
                case StateType.SYNTAX_GENERATION:
                    GenerateSyntax(info);
                    break;
                case StateType.VALIDATION:
                    ValidateQuery(info);
                    break;
                case StateType.SELF_HEAL:
                    SelfHeal(info);
                    break;
                case StateType.INSIGHT_SYNTHESIS:
                    SynthesizeInsights(info);
                    break;
            }
        }

        private void ParseIntent(StateInfo info)
        {
            var nlPrompt = info.Payload["natural_language_query"]?.ToString();
            var schema = _dbClient?.GetSchemaGraph();

            Logger?.LogInformation("[Data] Parsing intent: {Query}", nlPrompt);

            info.Payload["schema_graph"] = schema;
            info.ConversationHistory.Add(new ConversationTurn { Role = "user", Content = nlPrompt });

            Fsm.MoveTo(StateType.SYNTAX_GENERATION, new FiniteStateChangeEventArgs(StateType.INTENT_PARSING, StateType.SYNTAX_GENERATION, info)
            {
                TriggerEvent = "INTENT_PARSED"
            });
        }

        private void GenerateSyntax(StateInfo info)
        {
            var prompt = $"""
                You are the Data Synthesist. Convert the following natural language to SQL/Python.

                Intent: {info.Payload["natural_language_query"]}
                Schema: {info.Payload["schema_graph"]}
                Previous Errors: {string.Join("\n", info.DiagnosticLogs)}

                Generate executable, optimized code.
                """;

            var result = _inferenceEngine.ReasonAsync(prompt, info).GetAwaiter().GetResult();
            info.Payload["generated_code"] = result.Output;
            info.ConversationHistory.Add(new ConversationTurn { Role = "assistant", Content = result.Output });

            Fsm.MoveTo(StateType.VALIDATION, new FiniteStateChangeEventArgs(StateType.SYNTAX_GENERATION, StateType.VALIDATION, info)
            {
                TriggerEvent = "CODE_GENERATED"
            });
        }

        private void ValidateQuery(StateInfo info)
        {
            var code = info.Payload["generated_code"]?.ToString();
            Logger?.LogInformation("[Data] Validating generated code in sandbox...");

            var result = _sandbox?.Execute(code);

            if (result?.IsSuccess == true)
            {
                info.Payload["execution_result"] = result.Output;
                info.DiagnosticLogs.Add("[DATA] Validation passed.");

                Fsm.MoveTo(StateType.INSIGHT_SYNTHESIS, new FiniteStateChangeEventArgs(StateType.VALIDATION, StateType.INSIGHT_SYNTHESIS, info)
                {
                    TriggerEvent = "VALIDATION_PASSED"
                });
            }
            else
            {
                info.DiagnosticLogs.Add($"[DATA_ERROR] {result?.Error}");
                Fsm.MoveTo(StateType.SELF_HEAL, new FiniteStateChangeEventArgs(StateType.VALIDATION, StateType.SELF_HEAL, info)
                {
                    TriggerEvent = "VALIDATION_FAILED"
                });
            }
        }

        private void SelfHeal(StateInfo info)
        {
            Logger?.LogInformation("[Data] Self-healing query... Attempt {Retry}", info.RetryCount + 1);
            info.RetryCount++;

            // Append error context and loop back
            info.Payload["error_context"] = string.Join("\n", info.DiagnosticLogs);

            Fsm.MoveTo(StateType.SYNTAX_GENERATION, new FiniteStateChangeEventArgs(StateType.SELF_HEAL, StateType.SYNTAX_GENERATION, info)
            {
                TriggerEvent = "SELF_HEAL_RETRY"
            });
        }

        private void SynthesizeInsights(StateInfo info)
        {
            var result = info.Payload["execution_result"]?.ToString();
            var prompt = $"""
                Format the following data results into executive insights:
                {result}

                Provide summary, key metrics, and recommendations.
                """;

            var insight = _inferenceEngine.ReasonAsync(prompt, info).GetAwaiter().GetResult();
            info.Payload["insights"] = insight.Output;

            Logger?.LogInformation("[Data] Insights synthesized.");

            // Return to caller
            Fsm.MoveTo(StateType.IDLE, new FiniteStateChangeEventArgs(StateType.INSIGHT_SYNTHESIS, StateType.IDLE, info)
            {
                TriggerEvent = "INSIGHTS_COMPLETE"
            });
        }

        protected override void CleanupResources()
        {
            Logger?.LogInformation("[Data] Closing database connections...");
            _dbClient?.Dispose();
        }
    }
}
