using System;
using System.Diagnostics;
using AGI.FSM.Core;
using Microsoft.Extensions.Logging;

namespace AGI.FSM.Agents
{
    public class InfrastructureAgent : StateBase
    {
        private readonly IInferenceEngine _inferenceEngine;
        private readonly IKubernetesClient _k8s;
        private readonly IObservabilityClient _observability;

        public InfrastructureAgent(FiniteStateMachine fsm, IInferenceEngine engine, IKubernetesClient k8s, IObservabilityClient obs, ILogger logger)
            : base(fsm, StateType.ANOMALY_DETECTION, logger)
        {
            _inferenceEngine = engine;
            _k8s = k8s;
            _observability = obs;
        }

        protected override void AuthenticateServices(StateInfo info)
        {
            Logger?.LogInformation("[Infra] Authenticating with cloud providers...");
        }

        protected override void ExecuteReasoningLoop(float deltaTime)
        {
            var info = GetCurrentStateInfo();
            if (info == null) return;

            switch (Fsm.CurrentState)
            {
                case StateType.ANOMALY_DETECTION:
                    DetectAnomalies(info);
                    break;
                case StateType.ISOLATION:
                    IsolateResources(info);
                    break;
                case StateType.ROOT_CAUSE:
                    RunDiagnostics(info);
                    break;
                case StateType.REMEDIATION:
                    ExecuteRemediation(info);
                    break;
                case StateType.VERIFICATION:
                    VerifyRecovery(info);
                    break;
            }
        }

        private void DetectAnomalies(StateInfo info)
        {
            var metrics = _observability?.GetMetrics();
            if (metrics?.IsAnomaly == true)
            {
                Logger?.LogWarning("[Infra] Anomaly detected! CPU: {CPU}%, Memory: {Memory}%", metrics.Cpu, metrics.Memory);
                info.Payload["anomaly_metrics"] = metrics.ToJson();
                Fsm.MoveTo(StateType.ISOLATION, new FiniteStateChangeEventArgs(StateType.ANOMALY_DETECTION, StateType.ISOLATION, info)
                {
                    TriggerEvent = "ANOMALY_DETECTED"
                });
            }
        }

        private void IsolateResources(StateInfo info)
        {
            Logger?.LogInformation("[Infra] Isolating affected resources...");
            _k8s?.CordonNode(info.Payload["affected_node"]?.ToString());
            _k8s?.IsolateNetworkSegment(info.Payload["affected_service"]?.ToString());

            Fsm.MoveTo(StateType.ROOT_CAUSE, new FiniteStateChangeEventArgs(StateType.ISOLATION, StateType.ROOT_CAUSE, info)
            {
                TriggerEvent = "ISOLATION_COMPLETE"
            });
        }

        private void RunDiagnostics(StateInfo info)
        {
            var logs = _k8s?.CollectLogs(info.Payload["affected_pod"]?.ToString());
            var traces = _observability?.GetTraces();

            var prompt = $"""
                You are the Infrastructure Healer. Analyze the following diagnostic data:
                Logs: {logs}
                Traces: {traces}
                Metrics: {info.Payload["anomaly_metrics"]}

                Identify root cause and propose remediation steps.
                """;

            var result = _inferenceEngine.ReasonAsync(prompt, info).GetAwaiter().GetResult();
            info.Payload["diagnosis"] = result.Output;

            Fsm.MoveTo(StateType.REMEDIATION, new FiniteStateChangeEventArgs(StateType.ROOT_CAUSE, StateType.REMEDIATION, info)
            {
                TriggerEvent = "DIAGNOSIS_COMPLETE"
            });
        }

        private void ExecuteRemediation(StateInfo info)
        {
            var diagnosis = info.Payload["diagnosis"]?.ToString();
            Logger?.LogInformation("[Infra] Executing remediation: {Diagnosis}", diagnosis);

            // Execute fix
            _k8s?.ScaleDeployment(info.Payload["affected_deployment"]?.ToString(), 
                int.Parse(info.Payload["target_replicas"]?.ToString() ?? "3"));

            Fsm.MoveTo(StateType.VERIFICATION, new FiniteStateChangeEventArgs(StateType.REMEDIATION, StateType.VERIFICATION, info)
            {
                TriggerEvent = "REMEDIATION_EXECUTED"
            });
        }

        private void VerifyRecovery(StateInfo info)
        {
            var metrics = _observability?.GetMetrics();
            if (metrics?.IsHealthy == true)
            {
                Logger?.LogInformation("[Infra] Recovery verified. System healthy.");
                Fsm.MoveTo(StateType.IDLE, new FiniteStateChangeEventArgs(StateType.VERIFICATION, StateType.IDLE, info)
                {
                    TriggerEvent = "RECOVERY_VERIFIED"
                });
            }
            else
            {
                Logger?.LogError("[Infra] Recovery failed. Escalating to human.");
                Fsm.MoveTo(StateType.ESCALATION, new FiniteStateChangeEventArgs(StateType.VERIFICATION, StateType.ESCALATION, info)
                {
                    TriggerEvent = "RECOVERY_FAILED"
                });
            }
        }

        protected override void CleanupResources()
        {
            Logger?.LogInformation("[Infra] Cleaning up infrastructure locks...");
        }
    }
}
