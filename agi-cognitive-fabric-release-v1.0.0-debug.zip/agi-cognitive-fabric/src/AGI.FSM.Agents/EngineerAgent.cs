using System;
using System.Linq;
using AGI.FSM.Core;
using Microsoft.Extensions.Logging;

namespace AGI.FSM.Agents
{
    public class EngineerAgent : StateBase
    {
        private readonly IInferenceEngine _inferenceEngine;
        private readonly IGitHubClient _githubClient;
        private readonly ICIClient _ciClient;

        public EngineerAgent(FiniteStateMachine fsm, IInferenceEngine engine, IGitHubClient github, ICIClient ci, ILogger logger)
            : base(fsm, StateType.IMPLEMENT, logger)
        {
            _inferenceEngine = engine;
            _githubClient = github;
            _ciClient = ci;
        }

        protected override void AuthenticateServices(StateInfo info)
        {
            Logger?.LogInformation("[Engineer] Authenticating services...");
        }

        protected override void ExecuteReasoningLoop(float deltaTime)
        {
            var info = GetCurrentStateInfo();
            if (info == null) return;

            // Check retry limit
            if (info.RetryCount >= info.MaxRetries)
            {
                Logger?.LogError("[Engineer] Max retries exceeded. Escalating to human review.");
                Fsm.MoveTo(StateType.ESCALATION, new FiniteStateChangeEventArgs(StateType.IMPLEMENT, StateType.ESCALATION, info)
                {
                    TriggerEvent = "MAX_RETRIES_EXCEEDED"
                });
                return;
            }

            Logger?.LogInformation("[Engineer] Implementing code for Issue #{Issue} (Attempt {Retry}/{Max})", 
                info.GitHubIssueId, info.RetryCount + 1, info.MaxRetries);

            var designDoc = info.Payload["design_document"]?.ToString() ?? "No design document provided";

            var prompt = $"""
                You are the Engineer agent. Implement the following design as production code.

                Design Document: {designDoc}
                Issue: #{info.GitHubIssueId}
                Previous Errors: {string.Join("\n", info.DiagnosticLogs.Where(l => l.Contains("[CI_FAILURE]")))}

                Generate complete, tested code with comments.
                """;

            var result = _inferenceEngine.ReasonAsync(prompt, info).GetAwaiter().GetResult();

            if (result.Success)
            {
                // Write code to branch
                var branchName = $"agent-impl-{info.GitHubIssueId}-{DateTime.UtcNow:yyyyMMddHHmmss}";
                _githubClient?.CreateBranch(branchName);
                _githubClient?.CommitChanges(branchName, result.Output);

                // Trigger CI
                var pr = _githubClient?.CreatePullRequest(branchName, $"Agent Implementation: {info.GitHubIssueId}");
                info.Payload["pr_number"] = pr?.Number;
                info.Payload["branch_name"] = branchName;

                // Poll CI status
                var ciStatus = _ciClient?.PollStatus(pr?.Number);

                if (ciStatus?.IsSuccess == true)
                {
                    info.DiagnosticLogs.Add($"[ENGINEER] CI passed. PR #{pr?.Number}");
                    Fsm.MoveTo(StateType.REVIEW, new FiniteStateChangeEventArgs(StateType.IMPLEMENT, StateType.REVIEW, info)
                    {
                        TriggerEvent = "CI_SUCCESS"
                    });
                }
                else
                {
                    info.RetryCount++;
                    info.DiagnosticLogs.Add($"[CI_FAILURE] {ciStatus?.ErrorLog}");

                    // Self-correcting loop: REVISE instead of REVIEW
                    Fsm.MoveTo(StateType.SELF_HEAL, new FiniteStateChangeEventArgs(StateType.IMPLEMENT, StateType.SELF_HEAL, info)
                    {
                        TriggerEvent = "CI_FAILURE"
                    });
                }
            }
            else
            {
                info.DiagnosticLogs.Add($"[ENGINEER] Generation failed: {result.Error}");
                Fsm.MoveTo(StateType.RECOVERY, new FiniteStateChangeEventArgs(StateType.IMPLEMENT, StateType.RECOVERY, info)
                {
                    TriggerEvent = "GENERATION_FAILURE"
                });
            }
        }

        protected override void CleanupResources()
        {
            Logger?.LogInformation("[Engineer] Cleaning up build artifacts...");
        }
    }
}
