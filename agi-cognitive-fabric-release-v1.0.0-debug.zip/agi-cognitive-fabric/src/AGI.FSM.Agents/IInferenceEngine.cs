using System.Threading.Tasks;
using AGI.FSM.Core;

namespace AGI.FSM.Agents
{
    public interface IInferenceEngine
    {
        Task<InferenceResult> ReasonAsync(string prompt, StateInfo context, InferenceOptions options = null);
        Task<bool> ValidateAsync(string output, StateInfo context);
    }

    public class InferenceResult
    {
        public string Output { get; set; }
        public bool Success { get; set; }
        public string Error { get; set; }
        public int TokensUsed { get; set; }
        public long DurationMs { get; set; }
    }

    public class InferenceOptions
    {
        public float Temperature { get; set; } = 0.7f;
        public int MaxTokens { get; set; } = 4096;
        public string ModelId { get; set; } = "default";
    }
}
