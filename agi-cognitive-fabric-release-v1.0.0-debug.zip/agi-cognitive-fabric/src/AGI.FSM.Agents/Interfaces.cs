using System;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace AGI.FSM.Agents
{
    public interface IGitHubClient
    {
        string GetRepositoryContext(string issueId);
        void CreateBranch(string branchName);
        void CommitChanges(string branchName, string content);
        PullRequest CreatePullRequest(string branchName, string title);
    }

    public class PullRequest
    {
        public int Number { get; set; }
        public string Url { get; set; }
    }

    public interface ICIClient
    {
        CIStatus PollStatus(int? prNumber);
    }

    public class CIStatus
    {
        public bool IsSuccess { get; set; }
        public string ErrorLog { get; set; }
    }

    public interface IKubernetesClient
    {
        void CordonNode(string node);
        void IsolateNetworkSegment(string service);
        void ScaleDeployment(string deployment, int replicas);
        string CollectLogs(string pod);
    }

    public interface IObservabilityClient
    {
        MetricsSnapshot GetMetrics();
        string GetTraces();
    }

    public class MetricsSnapshot
    {
        public float Cpu { get; set; }
        public float Memory { get; set; }
        public bool IsAnomaly { get; set; }
        public bool IsHealthy { get; set; }
        public string ToJson() => JsonConvert.SerializeObject(this);
    }

    public interface IDatabaseClient : IDisposable
    {
        string GetSchemaGraph();
    }

    public interface ISandboxExecutor
    {
        SandboxResult Execute(string code);
    }

    public class SandboxResult
    {
        public bool IsSuccess { get; set; }
        public string Output { get; set; }
        public string Error { get; set; }
    }
}
