using System;
using System.Threading;
using AGI.FSM.Core;
using Microsoft.Extensions.Logging;

namespace AGI.FSM.Agents
{
    public class ArchitectAgent : StateBase
    {
        private readonly IInferenceEngine _inferenceEngine;
        private readonly IGitHubClient _githubClient;

        public ArchitectAgent(FiniteStateMachine fsm, IInferenceEngine engine, IGitHubClient github, ILogger logger)
            : base(fsm, StateType.DESIGN, logger)
        {
            _inferenceEngine = engine;
            _githubClient = github;
        }

        protected override void AuthenticateServices(StateInfo info)
        {
            Logger?.LogInformation("[Architect] Authenticating with GitHub API and LLM endpoint...");
            // GitHub token loaded from GITHUB_TOKEN env
            // LLM API key loaded from LLM_API_KEY env
        }

        protected override void ExecuteReasoningLoop(float deltaTime)
        {
            var info = GetCurrentStateInfo();
            if (info == null) return;

            Logger?.LogInformation("[Architect] Designing architecture for Issue #{Issue}", info.GitHubIssueId);

            // Load repository context
            var repoContext = _githubClient?.GetRepositoryContext(info.GitHubIssueId);

            // Construct design prompt
            var prompt = $"""
                You are the Architect agent. Design a technical specification for GitHub Issue #{info.GitHubIssueId}.

                Issue Context: {info.Payload["issue_body"]}
                Repository Structure: {repoContext}

                Output: A detailed design document with component breakdown, API contracts, and data models.
                """;

            var result = _inferenceEngine.ReasonAsync(prompt, info).GetAwaiter().GetResult();

            if (result.Success)
            {
                info.Payload["design_document"] = result.Output;
                info.DiagnosticLogs.Add($"[ARCHITECT] Design generated. Tokens: {result.TokensUsed}");

                // Transition to implementation
                Fsm.MoveTo(StateType.IMPLEMENT, new FiniteStateChangeEventArgs(StateType.DESIGN, StateType.IMPLEMENT, info)
                {
                    TriggerEvent = "DESIGN_COMPLETE"
                });
            }
            else
            {
                info.DiagnosticLogs.Add($"[ARCHITECT] Design failed: {result.Error}");
                Fsm.MoveTo(StateType.RECOVERY, new FiniteStateChangeEventArgs(StateType.DESIGN, StateType.RECOVERY, info)
                {
                    TriggerEvent = "DESIGN_FAILURE"
                });
            }
        }

        protected override void CleanupResources()
        {
            Logger?.LogInformation("[Architect] Cleaning up design resources...");
        }
    }
}
