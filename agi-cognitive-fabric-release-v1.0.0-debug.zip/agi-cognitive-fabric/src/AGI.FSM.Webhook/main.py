from fastapi import FastAPI, Request, Header, HTTPException
from fastapi.responses import JSONResponse
import hmac
import hashlib
import os
import json
import subprocess

app = FastAPI(title="AGI FSM Webhook Listener")

GITHUB_SECRET = os.environ.get("GITHUB_WEBHOOK_SECRET", "")
FSM_STATE_PATH = ".fsm/webhook-state.json"

@app.post("/webhook/github")
async def github_webhook(
    request: Request,
    x_github_event: str = Header(None),
    x_hub_signature_256: str = Header(None)
):
    """Receive GitHub webhooks and trigger FSM transitions."""

    payload = await request.body()

    # Verify signature
    if GITHUB_SECRET and x_hub_signature_256:
        expected = "sha256=" + hmac.new(
            GITHUB_SECRET.encode(),
            payload,
            hashlib.sha256
        ).hexdigest()
        if not hmac.compare_digest(expected, x_hub_signature_256):
            raise HTTPException(status_code=401, detail="Invalid signature")

    data = json.loads(payload)

    # Handle issue_comment events
    if x_github_event == "issue_comment":
        issue_number = data["issue"]["number"]
        comment_body = data["comment"]["body"]

        # Check for HALT command
        if "@agi-fsm halt" in comment_body.lower():
            # Trigger MoveTo(HALT)
            return JSONResponse({
                "status": "halt_requested",
                "issue": issue_number,
                "message": "FSM halt command received"
            })

        # Check for manual state transition
        if "@agi-fsm goto" in comment_body.lower():
            target_state = comment_body.split("goto")[1].strip().split()[0]
            return JSONResponse({
                "status": "transition_requested",
                "issue": issue_number,
                "target_state": target_state
            })

    # Handle issues events
    if x_github_event == "issues":
        action = data["action"]
        issue = data["issue"]

        if action == "opened" and "agent-request" in [l["name"] for l in issue.get("labels", [])]:
            # Trigger orchestrator workflow
            return JSONResponse({
                "status": "orchestration_triggered",
                "issue": issue["number"],
                "workflow": "auto-detect"
            })

    return JSONResponse({"status": "ignored", "event": x_github_event})

@app.get("/health")
async def health():
    return {"status": "healthy", "service": "agi-fsm-webhook"}

@app.get("/fsm/status")
async def fsm_status():
    """Return current FSM state for Agent HQ dashboard."""
    return {
        "current_state": "IDLE",
        "previous_state": "IDLE",
        "active_agents": [],
        "pending_transitions": [],
        "timestamp": "2024-01-01T00:00:00Z"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)
