#!/bin/bash
# AGI FSM - Systemd Installation Script
set -e

SERVICE_NAME="agi-fsm"
INSTALL_DIR="/opt/agi-fsm"
CONFIG_DIR="/etc/agi-fsm"

# Create user
sudo useradd -r -s /bin/false agi-fsm 2>/dev/null || true

# Create directories
sudo mkdir -p ${INSTALL_DIR} ${CONFIG_DIR}
sudo chown agi-fsm:agi-fsm ${INSTALL_DIR}

# Build and publish
echo "[systemd] Building debug release..."
dotnet publish ../../src/AGI.FSM.Host/AGI.FSM.Host.csproj     --configuration Debug     --output ${INSTALL_DIR}     --self-contained false

# Install service
echo "[systemd] Installing service..."
sudo cp agi-fsm.service /etc/systemd/system/
sudo systemctl daemon-reload

# Setup secrets
echo "[systemd] Configure secrets in ${CONFIG_DIR}/"
sudo touch ${CONFIG_DIR}/github-token
sudo touch ${CONFIG_DIR}/llm-key
sudo chmod 600 ${CONFIG_DIR}/*
sudo chown agi-fsm:agi-fsm ${CONFIG_DIR}/*

echo "[systemd] Installation complete."
echo "[systemd] Start with: sudo systemctl start agi-fsm"
echo "[systemd] Enable with: sudo systemctl enable agi-fsm"
echo "[systemd] Logs: sudo journalctl -u agi-fsm -f"
