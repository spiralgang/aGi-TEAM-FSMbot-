#!/bin/bash
# AGI FSM - Overlay Filesystem Deployment
# Creates ephemeral, layered state storage using overlayfs

set -e

LOWERDIR="/opt/agi-fsm/lower"
UPPERDIR="/opt/agi-fsm/upper"
WORKDIR="/opt/agi-fsm/work"
MERGED="/opt/agi-fsm/merged"

# Create overlay structure
mkdir -p ${LOWERDIR}/.fsm ${LOWERDIR}/logs
mkdir -p ${UPPERDIR}/.fsm ${UPPERDIR}/logs
mkdir -p ${WORKDIR}
mkdir -p ${MERGED}

# Mount overlayfs
echo "[overlay] Mounting overlay filesystem..."
mount -t overlay overlay     -o lowerdir=${LOWERDIR},upperdir=${UPPERDIR},workdir=${WORKDIR}     ${MERGED}

# Deploy application to lower (read-only base)
cp -r ../../src/AGI.FSM.Host/bin/Debug/net8.0/* ${LOWERDIR}/

# Run from merged (writable layer)
echo "[overlay] Starting FSM kernel in overlay environment..."
cd ${MERGED}
DOTNET_ENVIRONMENT=Development FSM_STATE_SECRET=AGI-FSM-OVERLAY-DEBUG-KEY     dotnet agi-fsm-host.dll "OVERLAY-DEBUG" &

FSM_PID=$!
echo "[overlay] FSM PID: ${FSM_PID}"

# On exit, commit upper layer to git
cleanup() {
    echo "[overlay] Committing state layer..."
    kill ${FSM_PID} 2>/dev/null || true

    # Persist upper layer changes
    cd ${UPPERDIR}
    git init 2>/dev/null || true
    git add .
    git commit -m "Overlay state snapshot $(date -Iseconds)" || true

    umount ${MERGED} || true
}
trap cleanup EXIT INT TERM

wait ${FSM_PID}
