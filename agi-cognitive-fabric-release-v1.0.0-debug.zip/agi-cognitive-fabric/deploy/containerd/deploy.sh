#!/bin/bash
# AGI FSM - Containerd Deployment Script
set -e

IMAGE="agi-fsm:debug"
CONTAINER_ID="agi-fsm-kernel"
NAMESPACE="default"

# Build image with buildctl (BuildKit)
echo "[containerd] Building debug image..."
buildctl build --frontend dockerfile.v0     --local context=../..     --local dockerfile=../alpine     --output type=oci,dest=agi-fsm-debug.tar

# Import into containerd
echo "[containerd] Importing to containerd..."
ctr -n ${NAMESPACE} image import agi-fsm-debug.tar

# Create OCI runtime bundle
echo "[containerd] Creating runtime bundle..."
mkdir -p /var/lib/agi-fsm/bundle
ctr -n ${NAMESPACE} image unpack ${IMAGE} /var/lib/agi-fsm/bundle/rootfs

# Copy spec
cp config.json /var/lib/agi-fsm/bundle/config.json

# Run with runc
echo "[containerd] Starting container via runc..."
runc run -b /var/lib/agi-fsm/bundle ${CONTAINER_ID}
