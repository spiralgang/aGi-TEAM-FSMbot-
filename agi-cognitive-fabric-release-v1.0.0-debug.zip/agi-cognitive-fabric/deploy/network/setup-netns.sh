#!/bin/bash
# AGI FSM - Network Namespace Isolation
# Creates isolated network environment for agent execution

set -e

NS_NAME="agi-fsm-net"
VETH_HOST="veth-agi-host"
VETH_NS="veth-agi-ns"
BRIDGE="agi-br0"
FSM_IP="10.200.1.2/24"
HOST_IP="10.200.1.1/24"

cleanup() {
    echo "[network] Cleaning up network namespace..."
    ip netns del ${NS_NAME} 2>/dev/null || true
    ip link del ${VETH_HOST} 2>/dev/null || true
    ip link del ${BRIDGE} 2>/dev/null || true
}
trap cleanup EXIT

echo "[network] Creating bridge ${BRIDGE}..."
ip link add ${BRIDGE} type bridge
ip addr add ${HOST_IP} dev ${BRIDGE}
ip link set ${BRIDGE} up

echo "[network] Creating namespace ${NS_NAME}..."
ip netns add ${NS_NAME}

echo "[network] Creating veth pair..."
ip link add ${VETH_HOST} type veth peer name ${VETH_NS}
ip link set ${VETH_HOST} master ${BRIDGE}
ip link set ${VETH_HOST} up
ip link set ${VETH_NS} netns ${NS_NAME}

ip netns exec ${NS_NAME} ip addr add ${FSM_IP} dev ${VETH_NS}
ip netns exec ${NS_NAME} ip link set ${VETH_NS} up
ip netns exec ${NS_NAME} ip link set lo up
ip netns exec ${NS_NAME} ip route add default via 10.200.1.1

# Enable IP forwarding and NAT
echo 1 > /proc/sys/net/ipv4/ip_forward
iptables -t nat -A POSTROUTING -s 10.200.1.0/24 -j MASQUERADE 2>/dev/null || true

echo "[network] Network namespace ready"
echo "[network] FSM will run at ${FSM_IP}"

# Run FSM in isolated network
echo "[network] Starting FSM kernel in network namespace..."
ip netns exec ${NS_NAME} bash -c '
    export DOTNET_ENVIRONMENT=Development
    export FSM_STATE_SECRET=AGI-FSM-NETWORK-DEBUG-KEY
    cd /opt/agi-fsm
    dotnet agi-fsm-host.dll "NETWORK-DEBUG"
'
